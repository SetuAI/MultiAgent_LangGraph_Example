"""
=============================================================================
ui/dashboard.py — Streamlit Interactive Dashboard
=============================================================================

WHAT THIS FILE DOES:
    Provides a rich, interactive web dashboard for the financial MAS.
    Users can:
        - Enter any stock ticker
        - Customize the analysis request
        - Watch agents work in real-time (progress indicators)
        - View formatted investment report
        - Explore individual metrics in expandable sections
        - See the agent execution timeline

STREAMLIT KEY CONCEPTS:
    - st.session_state: Persists data between user interactions
    - st.empty(): Placeholder that can be dynamically updated
    - @st.cache_data: Caches expensive computations
    - st.columns(): Side-by-side layout
    - st.expander(): Collapsible sections for details

ARCHITECTURE:
    Streamlit UI → directly calls graph/pipeline.py
    (bypasses FastAPI for simplicity in the UI layer)
    
    Alternatively: call the FastAPI endpoint from Streamlit for a
    fully decoupled architecture (see commented section at bottom)

=============================================================================
"""

# ── Third-party: Streamlit ─────────────────────────────────────────────────
import streamlit as st

# ── Standard library ──────────────────────────────────────────────────────
import time
import logging
import os
import sys

# Fix: add financial_mas/ to Python path so 'graph', 'agents' etc. are found
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# ── Third-party: Misc ─────────────────────────────────────────────────────
import json

logger = logging.getLogger(__name__)


# =============================================================================
# PAGE CONFIGURATION
# =============================================================================
# Must be the FIRST Streamlit command in the script

st.set_page_config(
    page_title="Financial MAS — LangGraph",
    page_icon="📈",
    layout="wide",                      # Use full screen width
    initial_sidebar_state="expanded",
)


# =============================================================================
# CUSTOM CSS STYLING
# =============================================================================
# Inject custom CSS to make the dashboard look polished

st.markdown("""
<style>
    /* Main header styling */
    .main-header {
        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
        padding: 2rem;
        border-radius: 12px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
    }
    
    /* Metric cards */
    .metric-card {
        background: #f8f9fa;
        border: 1px solid #e9ecef;
        border-radius: 8px;
        padding: 1rem;
        text-align: center;
        margin: 0.5rem 0;
    }
    
    /* Agent status badges */
    .agent-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 20px;
        font-size: 0.85rem;
        font-weight: 600;
        margin: 0.2rem;
    }
    
    .badge-running { background: #fff3cd; color: #856404; }
    .badge-done    { background: #d1e7dd; color: #0f5132; }
    .badge-waiting { background: #e2e3e5; color: #383d41; }
    
    /* Recommendation box */
    .rec-buy  { background: #d1e7dd; border-left: 5px solid #198754; padding: 1rem; border-radius: 0 8px 8px 0; }
    .rec-hold { background: #fff3cd; border-left: 5px solid #ffc107; padding: 1rem; border-radius: 0 8px 8px 0; }
    .rec-sell { background: #f8d7da; border-left: 5px solid #dc3545; padding: 1rem; border-radius: 0 8px 8px 0; }
    
    /* Report styling */
    .report-container {
        background: white;
        border: 1px solid #dee2e6;
        border-radius: 8px;
        padding: 1.5rem;
        line-height: 1.7;
    }
</style>
""", unsafe_allow_html=True)


# =============================================================================
# HELPER FUNCTIONS
# =============================================================================

def format_large_number(num: float) -> str:
    """
    Format large numbers for display (e.g., 3140000000000 → '$3.14T').
    Financial dashboards always format numbers in human-readable scale.
    """
    if not num or num == 0:
        return "N/A"
    if abs(num) >= 1e12:
        return f"${num/1e12:.2f}T"
    if abs(num) >= 1e9:
        return f"${num/1e9:.2f}B"
    if abs(num) >= 1e6:
        return f"${num/1e6:.2f}M"
    return f"${num:,.2f}"


def get_recommendation_color(rec: str) -> str:
    """Return CSS class based on recommendation text."""
    rec_upper = rec.upper()
    if "BUY" in rec_upper:
        return "rec-buy"
    elif "SELL" in rec_upper:
        return "rec-sell"
    else:
        return "rec-hold"


def get_risk_emoji(risk_level: str) -> str:
    """Return emoji for risk level."""
    mapping = {
        "LOW"    : "🟢",
        "MEDIUM" : "🟡",
        "HIGH"   : "🔴",
        "VERY HIGH": "🚨"
    }
    return mapping.get(str(risk_level).upper(), "⚪")


# =============================================================================
# SIDEBAR — Configuration Panel
# =============================================================================

with st.sidebar:
    st.markdown("## ⚙️ Configuration")

    # ── API Key Input ──────────────────────────────────────────────────────
    # Allow users to input their API key directly in the UI
    # Priority: UI input > environment variable
    api_key_input = st.text_input(
        "OpenAI API Key",
        value=os.getenv("OPENAI_API_KEY", ""),
        type="password",        # Hide the key in the UI
        help="Your OpenAI API key. We recommend setting OPENAI_API_KEY env var instead.",
        placeholder="sk-..."
    )

    # If user enters API key in UI, set it as env var for the session
    if api_key_input:
        os.environ["OPENAI_API_KEY"] = api_key_input

    st.divider()

    # ── Ticker Input ───────────────────────────────────────────────────────
    st.markdown("## 🎯 Analysis Target")

    # Quick selection buttons for popular tickers
    st.markdown("**Popular Tickers:**")
    col1, col2, col3 = st.columns(3)
    with col1:
        if st.button("AAPL"):
            st.session_state["ticker_input"] = "AAPL"
    with col2:
        if st.button("MSFT"):
            st.session_state["ticker_input"] = "MSFT"
    with col3:
        if st.button("NVDA"):
            st.session_state["ticker_input"] = "NVDA"

    col4, col5, col6 = st.columns(3)
    with col4:
        if st.button("TSLA"):
            st.session_state["ticker_input"] = "TSLA"
    with col5:
        if st.button("GOOG"):
            st.session_state["ticker_input"] = "GOOG"
    with col6:
        if st.button("AMZN"):
            st.session_state["ticker_input"] = "AMZN"

    st.divider()

    # ── Model Info ─────────────────────────────────────────────────────────
    st.markdown("## 🤖 System Info")
    st.info(
        "**Multi-Agent System**\n\n"
        "🔵 Supervisor Agent\n"
        "📊 Market Data Agent\n"
        "⚠️ Risk Analyst Agent\n"
        "📈 Fundamental Analyst\n"
        "📝 Report Writer Agent\n\n"
        "**Built with:** LangGraph + OpenAI"
    )

    st.divider()

    # ── Educational Explanation ────────────────────────────────────────────
    with st.expander("📚 How does this work?"):
        st.markdown("""
        This app demonstrates a **Multi-Agent System (MAS)** built with LangGraph.

        **Pipeline Flow:**
        1. **Supervisor** receives your request
        2. **Market Data Agent** fetches prices via yfinance
        3. **Risk Analyst** calculates volatility, beta, VaR
        4. **Fundamental Analyst** evaluates P/E, margins, debt
        5. **Report Writer** synthesizes a final investment brief

        Each agent is an **LLM + Tools** combination. Agents share state through a **typed dictionary** that acts as shared memory.

        The **supervisor** orchestrates which agent runs next — like a senior analyst directing a team.
        """)


# =============================================================================
# MAIN DASHBOARD AREA
# =============================================================================

# ── Header ─────────────────────────────────────────────────────────────────
st.markdown("""
<div class="main-header">
    <h1>📈 Financial Multi-Agent System</h1>
    <p style="margin:0; opacity:0.8">LangGraph × OpenAI × yfinance — Educational Demo</p>
</div>
""", unsafe_allow_html=True)

# ── Input Section ──────────────────────────────────────────────────────────
col_input, col_request = st.columns([1, 2])

with col_input:
    ticker = st.text_input(
        "📌 Stock Ticker",
        value=st.session_state.get("ticker_input", "AAPL"),
        placeholder="e.g., AAPL, MSFT, TSLA",
        help="Enter any US stock ticker symbol",
    ).upper().strip()

with col_request:
    analysis_request = st.text_area(
        "💬 Analysis Request",
        value="Provide a comprehensive investment analysis with buy/hold/sell recommendation",
        height=80,
        help="Customize what the AI agents should focus on",
    )

# ── Run Button ─────────────────────────────────────────────────────────────
run_col, info_col = st.columns([1, 3])

with run_col:
    run_button = st.button(
        "🚀 Run Analysis",
        type="primary",
        use_container_width=True,
        disabled=(not ticker or not os.getenv("OPENAI_API_KEY")),
    )

with info_col:
    if not os.getenv("OPENAI_API_KEY"):
        st.warning("⚠️ Please enter your OpenAI API key in the sidebar to run analysis")
    else:
        st.info(f"Ready to analyze **{ticker}** with 4 specialist AI agents. Estimated time: 30-60 seconds.")


# =============================================================================
# ANALYSIS EXECUTION
# =============================================================================

if run_button and ticker and os.getenv("OPENAI_API_KEY"):

    # ── Initialize result containers in session state ──────────────────────
    # st.session_state persists data between Streamlit reruns
    # (Streamlit reruns the entire script on every user interaction)
    st.session_state["analysis_running"] = True
    st.session_state["results"]          = None

    # ── Agent Progress Display ─────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 🔄 Agent Pipeline Execution")

    # Create status placeholders for each agent
    # st.empty() creates a placeholder that can be updated in-place
    progress_container = st.container()
    with progress_container:
        progress_bar = st.progress(0, text="Initializing pipeline...")

        # Individual agent status columns
        ag_col1, ag_col2, ag_col3, ag_col4, ag_col5 = st.columns(5)
        with ag_col1:
            supervisor_status    = st.empty()
            supervisor_status.markdown("🔵 **Supervisor**\n\n⏳ Waiting")
        with ag_col2:
            market_status        = st.empty()
            market_status.markdown("📊 **Market Data**\n\n⏳ Waiting")
        with ag_col3:
            risk_status          = st.empty()
            risk_status.markdown("⚠️ **Risk Analyst**\n\n⏳ Waiting")
        with ag_col4:
            fundamental_status   = st.empty()
            fundamental_status.markdown("📈 **Fundamental**\n\n⏳ Waiting")
        with ag_col5:
            report_status        = st.empty()
            report_status.markdown("📝 **Report Writer**\n\n⏳ Waiting")

    # Live log output
    log_expander = st.expander("📋 Live Agent Logs", expanded=True)
    log_container = log_expander.empty()
    log_lines = []

    # ── Import and run the pipeline ────────────────────────────────────────
    try:
        # Import here to avoid circular imports and to only load on demand
        from graph.pipeline import stream_financial_analysis

        start_time = time.time()
        final_state = {}

        # ── Stream the pipeline and update UI in real-time ─────────────────
        # Each chunk represents one agent completing its work
        for chunk in stream_financial_analysis(ticker, analysis_request):
            for node_name, state_update in chunk.items():

                # ── Update progress bar ────────────────────────────────────
                progress_map = {
                    "supervisor"                : (10, "Supervisor routing..."),
                    "market_data_agent"         : (35, "Market Data Agent working..."),
                    "risk_analyst_agent"        : (60, "Risk Analyst calculating metrics..."),
                    "fundamental_analyst_agent" : (80, "Fundamental Analyst evaluating..."),
                    "report_writer_agent"       : (95, "Report Writer synthesizing..."),
                }

                if node_name in progress_map:
                    pct, msg = progress_map[node_name]
                    progress_bar.progress(pct, text=f"🔄 {msg}")

                # ── Update agent status badges ─────────────────────────────
                if node_name == "supervisor":
                    supervisor_status.markdown("🔵 **Supervisor**\n\n✅ Done")
                elif node_name == "market_data_agent":
                    market_status.markdown("📊 **Market Data**\n\n✅ Done")
                    supervisor_status.markdown("🔵 **Supervisor**\n\n✅ Routing")
                elif node_name == "risk_analyst_agent":
                    risk_status.markdown("⚠️ **Risk Analyst**\n\n✅ Done")
                elif node_name == "fundamental_analyst_agent":
                    fundamental_status.markdown("📈 **Fundamental**\n\n✅ Done")
                elif node_name == "report_writer_agent":
                    report_status.markdown("📝 **Report Writer**\n\n✅ Done")

                # ── Update live log ────────────────────────────────────────
                agent_steps = state_update.get("agent_steps", [])
                for step in agent_steps:
                    log_lines.append(f"✅ {step}")

                # Update the log display
                if log_lines:
                    log_container.code("\n".join(log_lines[-20:]))  # Show last 20 lines

                # ── Accumulate final state ─────────────────────────────────
                # Merge each chunk's state update into our running final_state
                for k, v in state_update.items():
                    if isinstance(v, list) and isinstance(final_state.get(k), list):
                        final_state[k] = final_state.get(k, []) + v
                    elif v:  # Only overwrite if non-empty
                        final_state[k] = v

        # ── Pipeline complete ──────────────────────────────────────────────
        elapsed = time.time() - start_time
        progress_bar.progress(100, text=f"✅ Analysis complete! ({elapsed:.1f}s)")
        st.session_state["results"]         = final_state
        st.session_state["analysis_running"] = False

    except Exception as e:
        st.error(f"❌ Analysis failed: {str(e)}")
        st.exception(e)
        st.session_state["analysis_running"] = False


# =============================================================================
# RESULTS DISPLAY
# =============================================================================

if st.session_state.get("results"):
    state = st.session_state["results"]

    st.markdown("---")
    st.markdown(f"## 📊 Analysis Results: {state.get('company_name', ticker)} ({ticker})")

    # ── Row 1: Recommendation + Key Stats ─────────────────────────────────
    rec_col, stats_col = st.columns([1, 2])

    with rec_col:
        recommendation = state.get("recommendation", "HOLD | Confidence: MEDIUM")
        rec_class      = get_recommendation_color(recommendation)

        st.markdown(f"""
        <div class="{rec_class}">
            <h2 style="margin:0">{recommendation.split('|')[0].strip()}</h2>
            <p style="margin:0.5rem 0 0 0; font-size:0.9rem">
                {' | '.join(recommendation.split('|')[1:]).strip() if '|' in recommendation else ''}
            </p>
        </div>
        """, unsafe_allow_html=True)

    with stats_col:
        market_data  = state.get("market_data", {})
        risk_metrics = state.get("risk_metrics", {})
        fund_data    = state.get("fundamental_data", {})

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            price     = market_data.get("current_price", 0)
            chg_pct   = market_data.get("price_change_pct", 0)
            delta_str = f"{chg_pct:+.2f}%" if chg_pct else "N/A"
            st.metric("Current Price", f"${price:.2f}" if price else "N/A", delta_str)
        with m2:
            st.metric("Market Cap", format_large_number(market_data.get("market_cap", 0)))
        with m3:
            risk_level = risk_metrics.get("risk_level", "N/A")
            st.metric("Risk Level", f"{get_risk_emoji(risk_level)} {risk_level}")
        with m4:
            pe = fund_data.get("pe_ratio", 0)
            st.metric("P/E Ratio", f"{pe:.1f}x" if pe else "N/A")

    st.markdown("---")

    # ── Row 2: Detailed Metrics (3 columns) ───────────────────────────────
    tab1, tab2, tab3, tab4 = st.tabs(["📝 Investment Report", "⚠️ Risk Metrics", "📈 Fundamentals", "🔍 Agent Steps"])

    # ── Tab 1: Full Investment Report ─────────────────────────────────────
    with tab1:
        final_report = state.get("final_report", "No report generated")
        st.markdown(final_report)   # Render Markdown from report writer

    # ── Tab 2: Risk Metrics ────────────────────────────────────────────────
    with tab2:
        risk = state.get("risk_metrics", {})

        if risk:
            r_col1, r_col2, r_col3 = st.columns(3)

            with r_col1:
                st.markdown("### 📉 Volatility")
                st.metric(
                    "Annualized Volatility",
                    f"{risk.get('annualized_volatility_pct', 0):.1f}%",
                    help="Higher = more price swings. >40% = HIGH risk"
                )
                st.metric(
                    "Daily Volatility",
                    f"{risk.get('daily_volatility_pct', 0):.3f}%"
                )
                st.metric(
                    "Max Drawdown (1yr)",
                    f"-{risk.get('max_drawdown_pct', 0):.1f}%",
                    help="Largest peak-to-trough loss in the past year"
                )

            with r_col2:
                st.markdown("### ⚖️ Risk-Adjusted Returns")
                st.metric(
                    "Sharpe Ratio",
                    f"{risk.get('sharpe_ratio', 0):.2f}",
                    help=">2: Excellent | 1-2: Acceptable | <1: Poor"
                )
                st.metric(
                    "Beta",
                    f"{risk.get('beta', 'N/A')}",
                    help="vs S&P 500. >1 = more volatile than market"
                )
                st.metric(
                    "Avg Daily Return",
                    f"{risk.get('avg_daily_return_pct', 0):.3f}%"
                )

            with r_col3:
                st.markdown("### 🎯 Value at Risk")
                st.metric(
                    "VaR (95%, Daily)",
                    f"{risk.get('var_95_daily_pct', 0):.3f}%",
                    help="In 95% of days, loss will NOT exceed this %"
                )
                st.metric(
                    "Trading Days Analyzed",
                    risk.get("trading_days_analyzed", 0)
                )

            # Risk insights
            if state.get("risk_insights"):
                st.markdown("### 💡 Risk Analyst Insights")
                for insight in state["risk_insights"]:
                    if insight.strip():
                        st.markdown(f"• {insight}")

    # ── Tab 3: Fundamental Metrics ─────────────────────────────────────────
    with tab3:
        fund = state.get("fundamental_data", {})

        if fund:
            f_col1, f_col2, f_col3 = st.columns(3)

            with f_col1:
                st.markdown("### 💰 Valuation")
                st.metric("P/E Ratio (TTM)", f"{fund.get('pe_ratio', 0):.1f}x")
                st.metric("Forward P/E",     f"{fund.get('forward_pe', 0):.1f}x")
                st.metric("PEG Ratio",       f"{fund.get('peg_ratio', 0):.2f}")
                st.metric("Price/Book",      f"{fund.get('pb_ratio', 0):.2f}x")
                st.metric("EPS (TTM)",       f"${fund.get('eps_ttm', 0):.2f}")

            with f_col2:
                st.markdown("### 📊 Profitability")
                st.metric("Gross Margin",     f"{fund.get('gross_margin_pct', 0):.1f}%")
                st.metric("Operating Margin", f"{fund.get('operating_margin_pct', 0):.1f}%")
                st.metric("Net Margin",       f"{fund.get('net_margin_pct', 0):.1f}%")
                st.metric("ROE",              f"{fund.get('roe_pct', 0):.1f}%")
                st.metric("ROA",              f"{fund.get('roa_pct', 0):.1f}%")

            with f_col3:
                st.markdown("### 🏦 Financial Health")
                st.metric("Debt/Equity",    f"{fund.get('debt_to_equity', 0):.2f}x")
                st.metric("Current Ratio",  f"{fund.get('current_ratio', 0):.2f}x")
                st.metric("Quick Ratio",    f"{fund.get('quick_ratio', 0):.2f}x")
                st.metric("Revenue Growth", f"{fund.get('revenue_growth_pct', 0):.1f}%")
                st.metric("Free Cash Flow", format_large_number(fund.get("free_cash_flow_usd", 0)))

            # Fundamental insights
            if state.get("fundamental_insights"):
                st.markdown("### 💡 Fundamental Analyst Insights")
                for insight in state["fundamental_insights"]:
                    if insight.strip():
                        st.markdown(f"• {insight}")

    # ── Tab 4: Agent Execution Timeline ───────────────────────────────────
    with tab4:
        st.markdown("### 🔍 Agent Execution Steps")
        st.info(
            "This shows the chronological sequence of decisions made by each agent. "
            "This is the 'audit trail' — critical for compliance in production fintech systems."
        )

        agent_steps = state.get("agent_steps", [])
        for i, step in enumerate(agent_steps):
            # Parse agent name from step string for color coding
            if "SUPERVISOR" in step:
                st.markdown(f"**{i+1}.** 🔵 {step}")
            elif "MARKET_DATA" in step:
                st.markdown(f"**{i+1}.** 📊 {step}")
            elif "RISK_ANALYST" in step:
                st.markdown(f"**{i+1}.** ⚠️ {step}")
            elif "FUNDAMENTAL" in step:
                st.markdown(f"**{i+1}.** 📈 {step}")
            elif "REPORT_WRITER" in step:
                st.markdown(f"**{i+1}.** 📝 {step}")
            else:
                st.markdown(f"**{i+1}.** {step}")

        # Errors (if any)
        errors = state.get("errors", [])
        if errors:
            st.markdown("### ⚠️ Errors Encountered (Non-Fatal)")
            for err in errors:
                st.error(err)

        # Raw state viewer (for debugging/teaching)
        with st.expander("🔧 Raw State (Developer View)"):
            display_state = {
                k: v for k, v in state.items()
                if k not in ["messages", "historical_prices", "final_report"]
            }
            st.json(display_state)


# =============================================================================
# FOOTER
# =============================================================================

st.markdown("---")
st.markdown(
    """
    <div style="text-align: center; color: #6c757d; font-size: 0.85rem; padding: 1rem">
        📚 <strong>Financial Multi-Agent System</strong> — Educational Demo<br>
        Built with LangGraph + OpenAI + FastAPI + Streamlit<br>
        ⚠️ <em>This is NOT financial advice. For educational purposes only.</em>
    </div>
    """,
    unsafe_allow_html=True
)