"""
=============================================================================
tools/financial_tools.py — Financial Data & Calculation Tools
=============================================================================

WHY THIS FILE EXISTS:
    In LangGraph, "tools" are functions that agents can CALL to interact
    with the outside world (APIs, databases, calculators, etc.).

    Think of agents as smart decision-makers and tools as their "hands"
    — agents decide WHAT to do, tools actually DO the work.

TOOL DESIGN PRINCIPLES (from 10 years in fintech):
    1. ALWAYS validate inputs — garbage in, garbage out in financial systems
    2. ALWAYS return structured data with explicit typing
    3. ALWAYS handle failures gracefully — markets are unreliable data sources
    4. Document UNITS clearly (is it % or decimal? annualized or daily?)
    5. Log every data fetch for audit/compliance purposes

TOOLS DEFINED HERE:
    ┌─────────────────────────────────┬──────────────────────────────────┐
    │ Tool                            │ Used By                          │
    ├─────────────────────────────────┼──────────────────────────────────┤
    │ fetch_stock_price               │ Market Data Agent                │
    │ fetch_company_info              │ Market Data Agent                │
    │ calculate_technical_indicators  │ Risk Analyst Agent               │
    │ calculate_risk_metrics          │ Risk Analyst Agent               │
    │ fetch_fundamental_data          │ Fundamental Analyst Agent        │
    │ calculate_valuation_ratios      │ Fundamental Analyst Agent        │
    └─────────────────────────────────┴──────────────────────────────────┘

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import math                         # For sqrt in volatility calculations
import logging                      # For structured logging
from datetime import datetime       # For timestamping data fetches
from typing import Any              # For flexible return type hints

# ── Third-party: LangChain Tool Decorator ─────────────────────────────────
# @tool wraps a regular Python function into a LangChain-compatible tool
# that agents can discover, call, and receive structured results from
from langchain_core.tools import tool

# ── Third-party: Yahoo Finance ─────────────────────────────────────────────
# yfinance provides free financial data: prices, fundamentals, financials
# In production, you'd use Bloomberg, Refinitiv, or a paid data provider
import yfinance as yf

# ── Setup logging ──────────────────────────────────────────────────────────
# Use module-level logger — best practice over print() in production code
logger = logging.getLogger(__name__)


# =============================================================================
# TOOL 1: Fetch Live Stock Price Data
# =============================================================================

@tool                               # Decorator: registers this as a LangChain tool
def fetch_stock_price(ticker: str) -> dict[str, Any]:
    """
    Fetch current stock price and recent OHLCV (Open/High/Low/Close/Volume) data.

    WHY THIS TOOL:
        Before any analysis can happen, we need the raw price data.
        This is always the FIRST tool called in our pipeline.

    Args:
        ticker: Stock symbol (e.g., "AAPL", "MSFT", "TSLA")

    Returns:
        Dictionary with price data including:
            - current_price: Latest trading price in USD
            - previous_close: Yesterday's closing price
            - price_change: Dollar change from previous close
            - price_change_pct: Percentage change (e.g., 2.5 = 2.5%)
            - day_high / day_low: Today's intraday range
            - week_52_high / week_52_low: Annual price range (useful for context)
            - volume: Today's trading volume (shares)
            - avg_volume: 30-day average volume (compare to detect unusual activity)
            - market_cap: Total company value in USD
            - historical_prices: Last 30 days of closing prices (for volatility calc)
    """
    logger.info(f"[TOOL] fetch_stock_price called for ticker={ticker}")

    try:
        # Create a yfinance Ticker object
        # This is a lazy object — no API call yet, just a reference
        stock = yf.Ticker(ticker.upper())   # Always uppercase ticker symbols

        # Fetch the "fast info" dictionary — lightweight, single API call
        # Contains: current price, market cap, 52-week ranges, etc.
        info = stock.fast_info

        # Download 30 days of daily OHLCV data for historical analysis
        # period="1mo" = last 30 calendar days
        # interval="1d" = daily bars (as opposed to "1h" hourly or "5m" 5-minute)
        hist = stock.history(period="1mo", interval="1d")

        # Extract the closing price series as a Python list
        # We'll use these to calculate volatility and returns downstream
        closing_prices = hist["Close"].tolist() if not hist.empty else []

        # ── Build the response dictionary ──────────────────────────────────
        # Round all float values to 2 decimal places — financial convention
        result = {
            "ticker"            : ticker.upper(),
            "timestamp"         : datetime.now().isoformat(),  # Audit trail
            "current_price"     : round(float(info.last_price or 0), 2),
            "previous_close"    : round(float(info.previous_close or 0), 2),
            "price_change"      : round(
                                    float((info.last_price or 0) - (info.previous_close or 0)),
                                    2
                                  ),
            "price_change_pct"  : round(
                                    float(
                                        ((info.last_price or 0) - (info.previous_close or 0))
                                        / (info.previous_close or 1) * 100   # × 100 → percentage
                                    ),
                                    2
                                  ),
            "day_high"          : round(float(info.day_high or 0), 2),
            "day_low"           : round(float(info.day_low or 0), 2),
            "week_52_high"      : round(float(info.year_high or 0), 2),
            "week_52_low"       : round(float(info.year_low or 0), 2),
            "volume"            : int(info.last_volume or 0),
            "avg_volume"        : int(info.three_month_average_volume or 0),
            "market_cap"        : float(info.market_cap or 0),
            "historical_prices" : [round(p, 2) for p in closing_prices],
        }

        logger.info(f"[TOOL] fetch_stock_price SUCCESS: {ticker} @ ${result['current_price']}")
        return result

    except Exception as e:
        # NEVER let a tool crash the entire pipeline
        # Return an error dict — the calling agent will handle it
        logger.error(f"[TOOL] fetch_stock_price FAILED for {ticker}: {e}")
        return {"ticker": ticker, "error": str(e), "timestamp": datetime.now().isoformat()}


# =============================================================================
# TOOL 2: Fetch Company Info
# =============================================================================

@tool
def fetch_company_info(ticker: str) -> dict[str, Any]:
    """
    Fetch company metadata: name, sector, industry, description, employees.

    WHY THIS TOOL:
        Context matters in analysis. Knowing that Apple is in "Consumer Electronics"
        (not just "Technology") helps the analyst compare it to the right peers.

    Args:
        ticker: Stock symbol (e.g., "AAPL")

    Returns:
        Dictionary with company metadata including sector, industry, employees,
        country, website, and a brief business description.
    """
    logger.info(f"[TOOL] fetch_company_info called for ticker={ticker}")

    try:
        stock = yf.Ticker(ticker.upper())

        # .info is the comprehensive info dict — larger API call than fast_info
        # It includes company description, sector, industry, officers, etc.
        info = stock.info

        result = {
            "ticker"          : ticker.upper(),
            "company_name"    : info.get("longName", "Unknown"),
            "sector"          : info.get("sector", "Unknown"),
            "industry"        : info.get("industry", "Unknown"),
            "country"         : info.get("country", "Unknown"),
            "employees"       : info.get("fullTimeEmployees", 0),
            "website"         : info.get("website", ""),
            # Truncate description to 500 chars — LLM context efficiency
            "description"     : info.get("longBusinessSummary", "")[:500],
            "exchange"        : info.get("exchange", "Unknown"),
            "currency"        : info.get("currency", "USD"),
        }

        logger.info(f"[TOOL] fetch_company_info SUCCESS: {result['company_name']}")
        return result

    except Exception as e:
        logger.error(f"[TOOL] fetch_company_info FAILED for {ticker}: {e}")
        return {"ticker": ticker, "error": str(e)}


# =============================================================================
# TOOL 3: Calculate Risk Metrics
# =============================================================================

@tool
def calculate_risk_metrics(ticker: str) -> dict[str, Any]:
    """
    Calculate key risk metrics: volatility, beta, Sharpe ratio, and Value at Risk.

    FINANCIAL CONCEPTS TAUGHT:

    VOLATILITY (Standard Deviation of Returns):
        Measures how much the stock price FLUCTUATES.
        - Annualized by multiplying daily std dev by √252 (trading days/year)
        - >40% = high risk, 20-40% = medium, <20% = low risk
        - Formula: σ_annual = σ_daily × √252

    BETA:
        Measures how the stock moves RELATIVE to the market (S&P 500 = benchmark)
        - Beta = 1.0: moves exactly with the market
        - Beta > 1.0: more volatile than market (e.g., TSLA = ~2.0)
        - Beta < 1.0: less volatile (e.g., utilities = ~0.5)
        - Formula: β = Cov(stock, market) / Var(market)

    SHARPE RATIO:
        Risk-ADJUSTED return. How much return do you get per unit of risk?
        - Higher = better risk-adjusted performance
        - <1.0 = poor, 1-2 = acceptable, >2 = excellent
        - Formula: Sharpe = (Avg Return - Risk Free Rate) / Std Dev of Return
        - We use 5% annual (≈ 0.02% daily) as the risk-free rate (US T-Bill proxy)

    VALUE AT RISK (VaR) at 95% confidence:
        "There is a 95% chance we will NOT lose more than X% in a single day"
        - Calculated as: mean return - 1.645 × std dev of returns
        - 1.645 is the z-score for 95th percentile of normal distribution
        - Example: VaR = -2.3% means on a bad day, expect to lose ~2.3%

    Args:
        ticker: Stock symbol

    Returns:
        Dictionary with calculated risk metrics.
    """
    logger.info(f"[TOOL] calculate_risk_metrics called for ticker={ticker}")

    try:
        stock = yf.Ticker(ticker.upper())

        # Fetch 1 year of daily data for meaningful statistical analysis
        # Short periods give unreliable volatility estimates
        hist = stock.history(period="1y", interval="1d")

        if hist.empty or len(hist) < 10:
            # Can't calculate meaningful statistics with < 10 data points
            return {"ticker": ticker, "error": "Insufficient historical data"}

        # ── Calculate Daily Returns ────────────────────────────────────────
        # Daily return = (Today's Close - Yesterday's Close) / Yesterday's Close
        # .pct_change() does exactly this for every row in the Series
        # .dropna() removes the first row (NaN because no previous day exists)
        daily_returns = hist["Close"].pct_change().dropna()

        # Convert to a Python list for pure-Python calculations
        returns_list = daily_returns.tolist()

        # ── Mean and Standard Deviation of Daily Returns ───────────────────
        n = len(returns_list)                           # Number of return observations
        mean_return = sum(returns_list) / n             # Average daily return

        # Variance = average of squared deviations from mean
        variance = sum((r - mean_return) ** 2 for r in returns_list) / (n - 1)
        # Standard deviation = square root of variance
        daily_std = math.sqrt(variance)

        # ── Annualize Volatility ───────────────────────────────────────────
        # Multiply by √252 because: Var(annual) = 252 × Var(daily)
        # Therefore: Std(annual) = √252 × Std(daily)
        annualized_volatility = daily_std * math.sqrt(252)

        # ── Beta Calculation ───────────────────────────────────────────────
        # Fetch S&P 500 (^GSPC) data for the same period as benchmark
        spy = yf.Ticker("^GSPC")
        spy_hist = spy.history(period="1y", interval="1d")

        beta = None     # Default to None if beta can't be calculated
        if not spy_hist.empty:
            spy_returns = spy_hist["Close"].pct_change().dropna()

            # Align both return series by matching dates
            # Inner join: only keep dates where BOTH have data
            import pandas as pd
            aligned = pd.concat(
                [daily_returns, spy_returns],
                axis=1,
                join="inner"         # Drop dates where either series has NaN
            )
            aligned.columns = ["stock", "market"]

            if len(aligned) > 10:
                # Covariance between stock and market returns
                stock_ret = aligned["stock"].tolist()
                mkt_ret   = aligned["market"].tolist()
                n_aligned = len(stock_ret)

                # Mean of both series
                mean_s = sum(stock_ret) / n_aligned
                mean_m = sum(mkt_ret)   / n_aligned

                # Covariance formula: Σ[(stock_i - mean_s)(market_i - mean_m)] / (n-1)
                covariance = sum(
                    (stock_ret[i] - mean_s) * (mkt_ret[i] - mean_m)
                    for i in range(n_aligned)
                ) / (n_aligned - 1)

                # Market variance: Σ[(market_i - mean_m)²] / (n-1)
                market_variance = sum(
                    (mkt_ret[i] - mean_m) ** 2
                    for i in range(n_aligned)
                ) / (n_aligned - 1)

                # Beta = Cov(stock, market) / Var(market)
                beta = round(covariance / market_variance, 3) if market_variance != 0 else None

        # ── Sharpe Ratio ───────────────────────────────────────────────────
        # Risk-free rate: US 10-year T-Bill ≈ 5% annual = 5/252 daily
        risk_free_daily = 0.05 / 252        # Convert annual rate to daily

        # Excess return = actual return - risk-free return
        excess_returns = [r - risk_free_daily for r in returns_list]
        mean_excess    = sum(excess_returns) / len(excess_returns)

        # Sharpe = (Mean Excess Return / Std Dev) × √252 to annualize
        sharpe_ratio = (mean_excess / daily_std) * math.sqrt(252) if daily_std > 0 else 0

        # ── Value at Risk (VaR) at 95% confidence ─────────────────────────
        # Parametric VaR assumes returns are normally distributed
        # At 95% confidence: VaR = μ - 1.645σ
        # 1.645 is the z-score: P(Z < -1.645) = 5% (left tail)
        z_score_95 = 1.645
        var_95 = mean_return - (z_score_95 * daily_std)

        # ── Max Drawdown ───────────────────────────────────────────────────
        # Largest peak-to-trough decline over the period
        # Important for risk management: "how bad did it get?"
        prices = hist["Close"].tolist()
        peak = prices[0]                    # Track the running maximum price
        max_drawdown = 0.0
        for price in prices:
            if price > peak:
                peak = price               # New high — update peak
            drawdown = (peak - price) / peak  # Current drop from peak
            if drawdown > max_drawdown:
                max_drawdown = drawdown    # Track the worst drawdown seen

        result = {
            "ticker"                    : ticker.upper(),
            "annualized_volatility_pct" : round(annualized_volatility * 100, 2),   # As percentage
            "daily_volatility_pct"      : round(daily_std * 100, 4),               # As percentage
            "beta"                      : beta,
            "sharpe_ratio"              : round(sharpe_ratio, 3),
            "var_95_daily_pct"          : round(var_95 * 100, 3),                  # As percentage
            "max_drawdown_pct"          : round(max_drawdown * 100, 2),            # As percentage
            "avg_daily_return_pct"      : round(mean_return * 100, 4),             # As percentage
            "trading_days_analyzed"     : n,
            "risk_level"                : (                                         # Human-readable label
                "HIGH"   if annualized_volatility > 0.40 else
                "MEDIUM" if annualized_volatility > 0.20 else
                "LOW"
            ),
        }

        logger.info(f"[TOOL] calculate_risk_metrics SUCCESS for {ticker}: vol={result['annualized_volatility_pct']}%")
        return result

    except Exception as e:
        logger.error(f"[TOOL] calculate_risk_metrics FAILED for {ticker}: {e}")
        return {"ticker": ticker, "error": str(e)}


# =============================================================================
# TOOL 4: Fetch Fundamental Data
# =============================================================================

@tool
def fetch_fundamental_data(ticker: str) -> dict[str, Any]:
    """
    Fetch fundamental financial data: P/E ratio, EPS, revenue, margins, debt.

    FUNDAMENTAL ANALYSIS CONCEPTS:

    P/E RATIO (Price-to-Earnings):
        Stock Price / Earnings Per Share
        - "How much are investors paying for $1 of earnings?"
        - Industry-specific: Tech P/E ~25-40, Utilities ~15-20
        - High P/E = growth expectations OR overvaluation
        - Low P/E = value stock OR poor outlook

    EPS (Earnings Per Share):
        Net Income / Shares Outstanding
        - Profit attributed to each share
        - Growing EPS year-over-year = healthy business

    REVENUE GROWTH:
        % increase in top-line revenue year-over-year
        - Measures business expansion
        - >15% = high growth, 5-15% = moderate, <5% = mature

    PROFIT MARGINS:
        - Gross Margin  = (Revenue - COGS) / Revenue — operational efficiency
        - Operating Margin = Operating Income / Revenue — core business profitability
        - Net Margin   = Net Income / Revenue — bottom-line profitability

    DEBT-TO-EQUITY:
        Total Debt / Shareholders' Equity
        - Measures financial leverage/risk
        - <1.0 = conservative, 1-2 = moderate, >2 = aggressive

    RETURN ON EQUITY (ROE):
        Net Income / Shareholders' Equity
        - How efficiently is management using shareholders' money?
        - >15% = excellent, 10-15% = good, <10% = poor

    Args:
        ticker: Stock symbol

    Returns:
        Dictionary with fundamental valuation and financial health metrics.
    """
    logger.info(f"[TOOL] fetch_fundamental_data called for ticker={ticker}")

    try:
        stock = yf.Ticker(ticker.upper())

        # .info contains comprehensive fundamental data
        # Note: This makes a heavier API call than fast_info
        info = stock.info

        # Helper function: safely extract numeric value from info dict
        # Returns 0.0 if key is missing or None — prevents KeyError crashes
        def safe_get(key: str, default: float = 0.0) -> float:
            val = info.get(key, default)
            return float(val) if val is not None else default

        # ── Valuation Metrics ──────────────────────────────────────────────
        pe_ratio        = safe_get("trailingPE")       # Last 12 months P/E
        forward_pe      = safe_get("forwardPE")        # Next 12 months estimated P/E
        pb_ratio        = safe_get("priceToBook")      # Price / Book Value
        ps_ratio        = safe_get("priceToSalesTrailingTwelveMonths")  # Price / Revenue
        peg_ratio       = safe_get("pegRatio")         # P/E / Growth Rate (ideal: <1)
        eps_ttm         = safe_get("trailingEps")      # Earnings Per Share (last 12m)
        eps_forward     = safe_get("forwardEps")       # Estimated EPS next year

        # ── Growth Metrics ─────────────────────────────────────────────────
        rev_growth      = safe_get("revenueGrowth")    # YoY revenue growth (decimal)
        earnings_growth = safe_get("earningsGrowth")   # YoY earnings growth (decimal)
        revenue_ttm     = safe_get("totalRevenue")     # Total revenue last 12 months

        # ── Profitability Metrics ──────────────────────────────────────────
        gross_margin    = safe_get("grossMargins")     # (Revenue - COGS) / Revenue
        operating_margin= safe_get("operatingMargins") # Operating Income / Revenue
        net_margin      = safe_get("profitMargins")    # Net Income / Revenue
        roe             = safe_get("returnOnEquity")   # Net Income / Equity
        roa             = safe_get("returnOnAssets")   # Net Income / Total Assets
        ebitda          = safe_get("ebitda")           # Earnings before int/tax/dep/amort

        # ── Financial Health Metrics ───────────────────────────────────────
        debt_to_equity  = safe_get("debtToEquity")     # Total Debt / Equity
        current_ratio   = safe_get("currentRatio")     # Current Assets / Current Liabilities
        quick_ratio     = safe_get("quickRatio")       # (Current Assets - Inventory) / Curr Liab
        free_cash_flow  = safe_get("freeCashflow")     # Cash generated after capex

        # ── Dividend Info (relevant for income investors) ──────────────────
        dividend_yield  = safe_get("dividendYield")    # Annual dividend / current price
        payout_ratio    = safe_get("payoutRatio")      # Dividends / Net Income

        result = {
            "ticker"           : ticker.upper(),
            # Valuation
            "pe_ratio"         : round(pe_ratio, 2),
            "forward_pe"       : round(forward_pe, 2),
            "pb_ratio"         : round(pb_ratio, 2),
            "ps_ratio"         : round(ps_ratio, 2),
            "peg_ratio"        : round(peg_ratio, 2),
            "eps_ttm"          : round(eps_ttm, 2),
            "eps_forward"      : round(eps_forward, 2),
            # Growth
            "revenue_growth_pct"  : round(rev_growth * 100, 2),       # Convert to %
            "earnings_growth_pct" : round(earnings_growth * 100, 2),  # Convert to %
            "revenue_ttm_usd"     : round(revenue_ttm, 0),
            # Profitability
            "gross_margin_pct"    : round(gross_margin * 100, 2),
            "operating_margin_pct": round(operating_margin * 100, 2),
            "net_margin_pct"      : round(net_margin * 100, 2),
            "roe_pct"             : round(roe * 100, 2),
            "roa_pct"             : round(roa * 100, 2),
            "ebitda_usd"          : round(ebitda, 0),
            # Financial Health
            "debt_to_equity"      : round(debt_to_equity, 2),
            "current_ratio"       : round(current_ratio, 2),
            "quick_ratio"         : round(quick_ratio, 2),
            "free_cash_flow_usd"  : round(free_cash_flow, 0),
            # Dividend
            "dividend_yield_pct"  : round(dividend_yield * 100, 2),
            "payout_ratio_pct"    : round(payout_ratio * 100, 2),
        }

        logger.info(f"[TOOL] fetch_fundamental_data SUCCESS: PE={pe_ratio:.1f}, EPS={eps_ttm:.2f}")
        return result

    except Exception as e:
        logger.error(f"[TOOL] fetch_fundamental_data FAILED for {ticker}: {e}")
        return {"ticker": ticker, "error": str(e)}


# =============================================================================
# TOOL REGISTRY — Export all tools as a list for easy registration with agents
# =============================================================================
# When registering tools with an LLM agent, you pass a list of tool functions.
# Defining this list here means you import ONE thing, not four separate tools.

ALL_MARKET_TOOLS      = [fetch_stock_price, fetch_company_info]
ALL_RISK_TOOLS        = [calculate_risk_metrics]
ALL_FUNDAMENTAL_TOOLS = [fetch_fundamental_data]
ALL_TOOLS             = [fetch_stock_price, fetch_company_info,
                         calculate_risk_metrics, fetch_fundamental_data]