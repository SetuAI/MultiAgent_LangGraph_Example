"""
=============================================================================
api/server.py — FastAPI REST API Gateway
=============================================================================

WHAT THIS FILE DOES:
    Exposes the LangGraph multi-agent pipeline as a REST API.
    Any client (Streamlit UI, mobile app, other services) can call this
    API to trigger financial analysis without knowing anything about
    LangGraph, LLMs, or the internal agent architecture.

ENDPOINTS:
    POST /analyze        — Run full analysis (synchronous)
    GET  /analyze/stream — Stream analysis results (SSE)
    GET  /health         — Health check
    GET  /docs           — Auto-generated Swagger UI (FastAPI built-in)

WHY FASTAPI?
    - Automatic request/response validation via Pydantic models
    - Auto-generated OpenAPI docs at /docs (great for teaching!)
    - Async support — can handle multiple concurrent analysis requests
    - Fast — built on Starlette/uvicorn, production-grade performance

FASTAPI vs FLASK for AI APIs:
    FastAPI advantages:
        ✓ Type hints → automatic validation + documentation
        ✓ Async first (important for long-running LLM calls)
        ✓ Built-in Swagger UI for exploring the API
        ✓ Pydantic integration is seamless
    Flask advantages:
        ✓ Simpler mental model
        ✓ Larger existing codebase ecosystem

    For AI APIs in production fintech, FastAPI is the industry standard.

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import logging
import time                             # For tracking execution duration
from datetime import datetime
from typing import Optional

# ── Third-party: FastAPI ───────────────────────────────────────────────────
from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware  # Allow cross-origin requests
from fastapi.responses import StreamingResponse     # For SSE streaming
import json

# ── Third-party: Pydantic ──────────────────────────────────────────────────
# Pydantic models define the shape of API request/response bodies
# FastAPI automatically validates incoming JSON against these models
from pydantic import BaseModel, Field, validator

# ── Internal imports ───────────────────────────────────────────────────────
from core.config import settings
from graph.pipeline import run_financial_analysis, stream_financial_analysis

# ── Configure logging ──────────────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,                         # Log INFO and above
    format="%(asctime)s | %(name)s | %(levelname)s | %(message)s"
)
logger = logging.getLogger(__name__)


# =============================================================================
# FASTAPI APPLICATION INSTANCE
# =============================================================================

app = FastAPI(
    title="Financial Multi-Agent Analysis API",
    description=(
        "A LangGraph-powered multi-agent system for financial analysis. "
        "Orchestrates Market Data, Risk Analyst, Fundamental Analyst, and "
        "Report Writer agents to produce comprehensive investment briefs."
    ),
    version=settings.app_version,
    docs_url="/docs",       # Swagger UI available at: http://localhost:8000/docs
    redoc_url="/redoc",     # ReDoc UI available at: http://localhost:8000/redoc
)

# ── CORS Middleware ────────────────────────────────────────────────────────
# CORS = Cross-Origin Resource Sharing
# Required to allow the Streamlit UI (running on port 8501) to call this API
# (running on port 8000). Without this, browsers block the request.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],            # In production: restrict to specific domains
    allow_credentials=True,
    allow_methods=["*"],            # Allow GET, POST, etc.
    allow_headers=["*"],
)


# =============================================================================
# PYDANTIC REQUEST/RESPONSE MODELS
# =============================================================================
# These models serve double duty:
#   1. Validation: FastAPI automatically rejects malformed requests
#   2. Documentation: FastAPI auto-generates schema for Swagger UI

class AnalysisRequest(BaseModel):
    """
    Request body for triggering a financial analysis.

    FastAPI will:
        - Parse incoming JSON into this model
        - Return 422 Unprocessable Entity if validation fails
        - Show this schema in the Swagger docs
    """
    ticker: str = Field(
        ...,                                    # Required field (no default)
        min_length=1,
        max_length=10,
        description="Stock ticker symbol (e.g., AAPL, MSFT, TSLA)",
        example="AAPL"
    )
    analysis_request: Optional[str] = Field(
        default="Provide a comprehensive investment analysis with buy/hold/sell recommendation",
        description="Custom analysis instruction or focus area",
        example="Focus on growth potential and valuation for a 5-year investment horizon"
    )

    @validator("ticker")
    def ticker_must_be_uppercase(cls, v):
        """Auto-convert ticker to uppercase. AAPL, aapl, Aapl all work."""
        return v.upper().strip()


class RiskMetrics(BaseModel):
    """Structured risk metrics from the Risk Analyst Agent."""
    risk_level: str
    annualized_volatility_pct: float
    beta: Optional[float]
    sharpe_ratio: float
    var_95_daily_pct: float
    max_drawdown_pct: float


class AnalysisResponse(BaseModel):
    """
    Response body returned after a completed analysis.

    Contains both raw metrics (for programmatic use) and
    the human-readable report (for display purposes).
    """
    # Metadata
    ticker: str
    company_name: str
    analysis_timestamp: str
    execution_time_seconds: float
    status: str                             # "success" or "error"

    # Agent outputs
    recommendation: str                     # "BUY | Confidence: HIGH"
    final_report: str                       # Full Markdown investment brief

    # Key metrics (subset — full data in market_data / risk_metrics)
    current_price: Optional[float]
    market_cap: Optional[float]
    risk_level: Optional[str]
    pe_ratio: Optional[float]

    # Audit trail
    agent_steps: list[str]
    errors: list[str]


# =============================================================================
# HEALTH CHECK ENDPOINT
# =============================================================================

@app.get(
    "/health",
    tags=["System"],
    summary="Health check"
)
async def health_check():
    """
    Simple health check to verify the API is running.
    Used by:
        - Load balancers to check if the service is up
        - Kubernetes readiness/liveness probes
        - Monitoring systems (Datadog, PagerDuty)

    Returns: {"status": "healthy", "timestamp": "...", "version": "..."}
    """
    return {
        "status"    : "healthy",
        "timestamp" : datetime.now().isoformat(),
        "version"   : settings.app_version,
        "model"     : settings.llm_model,
    }


# =============================================================================
# MAIN ANALYSIS ENDPOINT
# =============================================================================

@app.post(
    "/analyze",
    response_model=AnalysisResponse,    # FastAPI validates the response matches this model
    tags=["Analysis"],
    summary="Run full multi-agent financial analysis",
    description=(
        "Triggers the full LangGraph pipeline: "
        "Supervisor → Market Data Agent → Risk Analyst → "
        "Fundamental Analyst → Report Writer. "
        "Returns a complete investment brief with recommendation. "
        "Typical execution time: 30-60 seconds."
    )
)
async def analyze_stock(request: AnalysisRequest):
    """
    Run the full financial analysis pipeline for a given stock.

    FLOW:
        1. Validate request (Pydantic does this automatically)
        2. Start the LangGraph pipeline
        3. Wait for all 4 agents to complete (synchronous execution)
        4. Package the final state into a structured response
        5. Return the response

    Note: For long-running analyses, consider the /analyze/stream endpoint
    which returns results progressively as each agent completes.
    """
    logger.info(f"[API] Received analysis request for ticker: {request.ticker}")

    start_time = time.time()    # Track execution duration

    try:
        # ── Run the full pipeline ──────────────────────────────────────────
        # run_financial_analysis blocks until ALL agents complete
        # Typical duration: 30-60 seconds for 4 LLM calls + API calls
        final_state = run_financial_analysis(
            ticker=request.ticker,
            analysis_request=request.analysis_request,
        )

        execution_time = time.time() - start_time
        logger.info(f"[API] Analysis complete in {execution_time:.1f}s")

        # ── Extract key metrics for the structured response ────────────────
        market_data  = final_state.get("market_data", {})
        fund_data    = final_state.get("fundamental_data", {})
        risk_metrics = final_state.get("risk_metrics", {})

        # ── Build and return the response ─────────────────────────────────
        return AnalysisResponse(
            # Metadata
            ticker                  = request.ticker,
            company_name            = final_state.get("company_name", request.ticker),
            analysis_timestamp      = datetime.now().isoformat(),
            execution_time_seconds  = round(execution_time, 2),
            status                  = "success",

            # Core outputs
            recommendation  = final_state.get("recommendation", "HOLD | Confidence: LOW"),
            final_report    = final_state.get("final_report", "Report generation failed"),

            # Key metrics (flattened from nested dicts for convenience)
            current_price   = market_data.get("current_price"),
            market_cap      = market_data.get("market_cap"),
            risk_level      = risk_metrics.get("risk_level"),
            pe_ratio        = fund_data.get("pe_ratio"),

            # Audit trail
            agent_steps     = final_state.get("agent_steps", []),
            errors          = final_state.get("errors", []),
        )

    except Exception as e:
        # ── Structured error response ──────────────────────────────────────
        # Always return a structured error — never let stack traces leak to clients
        execution_time = time.time() - start_time
        logger.error(f"[API] Analysis FAILED for {request.ticker}: {e}", exc_info=True)

        # 500 Internal Server Error with a human-readable message
        raise HTTPException(
            status_code=500,
            detail={
                "error"              : str(e),
                "ticker"             : request.ticker,
                "execution_time_s"   : round(execution_time, 2),
                "message"            : "Analysis pipeline failed. Check server logs for details.",
            }
        )


# =============================================================================
# STREAMING ANALYSIS ENDPOINT
# =============================================================================

@app.get(
    "/analyze/stream",
    tags=["Analysis"],
    summary="Stream analysis results in real-time (SSE)",
    description=(
        "Streams analysis results as Server-Sent Events (SSE). "
        "Each event represents one agent completing its work. "
        "Ideal for showing progress in a UI without waiting for the full result."
    )
)
async def stream_analysis(
    ticker: str,
    analysis_request: str = "Provide a comprehensive investment analysis"
):
    """
    Stream the financial analysis pipeline results in real-time.

    WHY STREAMING?
        The full analysis takes 30-60 seconds. Without streaming, the user
        sees a loading spinner for the entire duration.
        With streaming, they see:
            "✓ Market data fetched (5s)"
            "✓ Risk analysis complete (20s)"
            "✓ Fundamental analysis complete (35s)"
            "✓ Report generated (55s)"

    SERVER-SENT EVENTS (SSE):
        SSE is a simple HTTP-based protocol for streaming:
        - Client opens a persistent HTTP connection
        - Server sends text events: "data: {json}\n\n"
        - Client receives events as they're sent
        - Connection closes when server sends a final event

    Returns:
        A streaming response with SSE-formatted events
    """
    ticker = ticker.upper().strip()
    logger.info(f"[API STREAM] Starting streamed analysis for {ticker}")

    def generate_sse_events():
        """
        Generator function that yields SSE-formatted events.
        Each agent's completion is one event.
        """
        try:
            # Stream the pipeline — each chunk is one agent's output
            for chunk in stream_financial_analysis(ticker, analysis_request):
                # chunk = {node_name: {partial_state_update}}
                for node_name, state_update in chunk.items():
                    # Format as SSE: "data: {json}\n\n"
                    # The \n\n is REQUIRED by the SSE protocol to signal end of event
                    event_data = {
                        "agent"     : node_name,
                        "status"    : "completed",
                        "data"      : {
                            k: v for k, v in state_update.items()
                            # Exclude heavy fields from intermediate events
                            if k not in ["messages", "historical_prices"]
                        },
                    }
                    # SSE format: data: {json}\n\n
                    yield f"data: {json.dumps(event_data)}\n\n"

            # Send final "done" event to signal stream completion
            yield f"data: {json.dumps({'agent': 'PIPELINE', 'status': 'complete'})}\n\n"

        except Exception as e:
            logger.error(f"[API STREAM] Streaming failed: {e}")
            error_event = {"agent": "PIPELINE", "status": "error", "error": str(e)}
            yield f"data: {json.dumps(error_event)}\n\n"

    # Return a StreamingResponse with the SSE media type
    return StreamingResponse(
        generate_sse_events(),
        media_type="text/event-stream",         # Required for SSE
        headers={
            "Cache-Control" : "no-cache",       # Don't cache streaming responses
            "X-Accel-Buffering": "no",          # Disable nginx buffering
        }
    )


# =============================================================================
# QUICK METRICS ENDPOINT (No LLM — Fast)
# =============================================================================

@app.get(
    "/metrics/{ticker}",
    tags=["Data"],
    summary="Get raw financial metrics without AI analysis",
)
async def get_raw_metrics(ticker: str):
    """
    Fetch raw financial metrics WITHOUT running the full AI pipeline.
    This endpoint is fast (2-5 seconds) because it only calls yfinance,
    not any LLM agents.

    Use this for:
        - Quick data checks
        - Building dashboards with raw data
        - Testing that yfinance is working correctly
    """
    from tools.financial_tools import fetch_stock_price, fetch_fundamental_data, calculate_risk_metrics

    ticker = ticker.upper().strip()
    logger.info(f"[API] Fetching raw metrics for {ticker}")

    try:
        # Call tools directly (no LLM involved)
        price_data      = fetch_stock_price.invoke({"ticker": ticker})
        fundamental     = fetch_fundamental_data.invoke({"ticker": ticker})
        risk            = calculate_risk_metrics.invoke({"ticker": ticker})

        return {
            "ticker"        : ticker,
            "timestamp"     : datetime.now().isoformat(),
            "price_data"    : price_data,
            "risk_metrics"  : risk,
            "fundamentals"  : fundamental,
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# =============================================================================
# STARTUP EVENT
# =============================================================================

@app.on_event("startup")
async def startup_event():
    """
    Runs once when the FastAPI server starts up.
    Use this for:
        - Warming up model connections
        - Validating API keys
        - Pre-loading the LangGraph graph
        - Connecting to databases
    """
    logger.info(f"[STARTUP] {settings.app_name} v{settings.app_version} starting up...")
    logger.info(f"[STARTUP] LLM Model: {settings.llm_model}")
    logger.info(f"[STARTUP] OpenAI API Key configured: {'Yes' if settings.openai_api_key else 'NO — SET OPENAI_API_KEY!'}")
    logger.info("[STARTUP] API ready. Visit http://localhost:8000/docs for Swagger UI")


# =============================================================================
# DIRECT EXECUTION
# =============================================================================
# Allows running the server directly: python api/server.py

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "api.server:app",
        host="0.0.0.0",     # Listen on all interfaces
        port=8000,
        reload=True,        # Auto-reload on code changes (development only!)
        log_level="info",
    )