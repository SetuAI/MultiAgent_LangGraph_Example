"""
=============================================================================
agents/market_data_agent.py — Market Data Specialist Agent
=============================================================================

WHAT THIS AGENT DOES:
    This is the "data procurement" agent — it runs first in the pipeline
    and fetches all raw market data needed by downstream agents.

    Real-world analogy: The junior analyst who gets everything ready
    before the senior analysts start their analysis.

HOW A TOOL-CALLING AGENT WORKS IN LANGGRAPH:
    ┌────────────────────────────────────────────────────────────┐
    │  1. Agent receives state (has ticker, needs market_data)   │
    │  2. Agent calls LLM with:                                  │
    │       - System prompt (its "job description")              │
    │       - User message (what to fetch)                       │
    │       - Available tools (what it can call)                 │
    │  3. LLM decides to call tools:                             │
    │       fetch_stock_price("AAPL") → {price: 185.20, ...}    │
    │       fetch_company_info("AAPL") → {sector: "Tech", ...}  │
    │  4. Tool results are fed back to the LLM                   │
    │  5. LLM synthesizes tool results into a coherent response  │
    │  6. Agent updates state with structured data               │
    └────────────────────────────────────────────────────────────┘

DESIGN DECISION — Why use LLM for data fetching?
    We COULD just call yfinance directly without an LLM.
    But using an LLM-powered agent:
        - Handles errors gracefully in natural language
        - Can interpret ambiguous tickers
        - Makes the architecture consistent (everything is an agent)
        - Demonstrates the full tool-calling pattern to students

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import json                             # For parsing LLM tool call results
import logging
from typing import Any

# ── Third-party: LangChain ─────────────────────────────────────────────────
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, ToolMessage

# ── Internal imports ───────────────────────────────────────────────────────
from core.config import settings, FinancialAnalysisState
from tools.financial_tools import fetch_stock_price, fetch_company_info, ALL_MARKET_TOOLS

logger = logging.getLogger(__name__)


# =============================================================================
# AGENT SYSTEM PROMPT
# =============================================================================
# The system prompt is the agent's "job description" — it tells the LLM
# what role it's playing and what its responsibilities are.
# Clear, specific system prompts are the #1 factor in agent quality.

MARKET_DATA_AGENT_PROMPT = """You are a specialized Market Data Agent at a quantitative hedge fund.

Your ONLY job is to fetch accurate market data for a given stock ticker.

RESPONSIBILITIES:
1. Fetch the current stock price and recent OHLCV data using fetch_stock_price
2. Fetch company metadata using fetch_company_info
3. Return the raw data — do NOT analyze or interpret it

TOOLS AVAILABLE:
- fetch_stock_price(ticker): Gets current price, change, volume, 52-week range
- fetch_company_info(ticker): Gets company name, sector, industry, description

IMPORTANT:
- Always call BOTH tools for completeness
- If a tool fails, report the error but continue with available data
- Do not make up or hallucinate any financial numbers
- Return data as-is from the tools — no modification

Output format: Summarize what data was fetched in 2-3 sentences.
"""


# =============================================================================
# MARKET DATA AGENT NODE FUNCTION
# =============================================================================

def market_data_agent_node(state: FinancialAnalysisState) -> dict:
    """
    Market Data Agent: fetches raw stock price and company information.

    This agent uses a "ReAct" (Reason + Act) pattern:
        - Reason: LLM decides WHICH tools to call and with WHAT arguments
        - Act: Tools execute and return results
        - Observe: LLM reads results and decides if more tools are needed

    Args:
        state: Current pipeline state (must have 'ticker' field)

    Returns:
        Partial state update with 'market_data' and 'company_name' populated
    """
    ticker = state.get("ticker", "UNKNOWN").upper()
    logger.info(f"[MARKET DATA AGENT] Starting data fetch for {ticker}")

    # ── Initialize the LLM ─────────────────────────────────────────────────
    # bind_tools() tells the LLM what tools it can call
    # The LLM will emit "tool_call" messages when it wants to use a tool
    llm = ChatOpenAI(
        model=settings.llm_model,
        temperature=settings.analyst_temperature,   # Low temp = consistent output
        api_key=settings.openai_api_key,
    ).bind_tools(ALL_MARKET_TOOLS)  # Register available tools with the LLM

    # ── Build the message conversation ────────────────────────────────────
    # LangChain uses a message-based API:
    #   SystemMessage = persistent instructions (the "system prompt")
    #   HumanMessage  = the user's request
    messages = [
        SystemMessage(content=MARKET_DATA_AGENT_PROMPT),
        HumanMessage(
            content=f"Fetch all market data for ticker: {ticker}\n"
                    f"Analysis request context: {state.get('analysis_request', 'General analysis')}"
        ),
    ]

    # ── Agentic Loop ───────────────────────────────────────────────────────
    # This loop runs until the LLM stops calling tools (finish_reason = "stop")
    # In practice, this agent will:
    #   Turn 1: LLM calls fetch_stock_price + fetch_company_info
    #   Turn 2: LLM receives tool results, writes summary, stops

    collected_data = {}     # Accumulate tool results here
    max_iterations  = 5     # Safety limit: prevent infinite loops

    for iteration in range(max_iterations):
        logger.info(f"[MARKET DATA AGENT] LLM call iteration {iteration + 1}")

        # Call the LLM with current messages
        response = llm.invoke(messages)

        # ── Check if LLM wants to call tools ──────────────────────────────
        # response.tool_calls is a list of tool invocations the LLM requested
        # If empty, the LLM is done and wants to give a final text response
        if not response.tool_calls:
            # LLM gave a final text response — we're done with the loop
            logger.info("[MARKET DATA AGENT] LLM finished tool calling")
            break

        # ── Execute each tool call ─────────────────────────────────────────
        # Add the assistant's tool-call message to conversation history
        messages.append(response)   # Important: keeps conversation coherent

        for tool_call in response.tool_calls:
            tool_name = tool_call["name"]   # Which tool the LLM wants to call
            tool_args = tool_call["args"]   # Arguments the LLM chose to pass

            logger.info(f"[MARKET DATA AGENT] Calling tool: {tool_name}({tool_args})")

            # ── Dispatch tool call to the correct function ─────────────────
            # We manually route by name here for clarity
            # LangGraph's prebuilt ToolNode does this automatically,
            # but manual dispatch is more educational
            if tool_name == "fetch_stock_price":
                tool_result = fetch_stock_price.invoke(tool_args)
                collected_data["price_data"] = tool_result    # Store result

            elif tool_name == "fetch_company_info":
                tool_result = fetch_company_info.invoke(tool_args)
                collected_data["company_data"] = tool_result  # Store result

            else:
                tool_result = {"error": f"Unknown tool: {tool_name}"}

            # ── Feed tool result back to the LLM ──────────────────────────
            # ToolMessage tells the LLM: "Here's what that tool returned"
            # tool_call_id links this result to the specific tool_call above
            messages.append(
                ToolMessage(
                    content=json.dumps(tool_result),    # Tool result as JSON string
                    tool_call_id=tool_call["id"],       # Match to the tool_call
                )
            )

    # ── Extract and structure the collected data ───────────────────────────
    price_data   = collected_data.get("price_data", {})
    company_data = collected_data.get("company_data", {})

    # Merge both data sources into one clean market_data dict
    market_data = {**price_data, **company_data}

    # Extract company name for use in other agents' prompts
    company_name = company_data.get("company_name", ticker)

    logger.info(f"[MARKET DATA AGENT] Complete. Fetched data for {company_name}")

    # ── Return state update ────────────────────────────────────────────────
    # Only return the fields we're updating — LangGraph merges with existing state
    return {
        "market_data"  : market_data,
        "company_name" : company_name,
        "agent_steps"  : [f"MARKET_DATA_AGENT: Fetched price=${price_data.get('current_price', 'N/A')} for {ticker}"],
    }