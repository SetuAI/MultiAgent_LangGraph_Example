"""
=============================================================================
agents/risk_analyst_agent.py — Risk Analyst Specialist Agent
=============================================================================

WHAT THIS AGENT DOES:
    This agent acts as a quantitative risk analyst. It:
    1. Fetches calculated risk metrics using the calculate_risk_metrics tool
    2. INTERPRETS those metrics in the context of the specific company
    3. Generates risk insights: key findings, red flags, risk-adjusted outlook

    Real-world analogy: The quant risk desk at an investment bank that
    assesses whether a stock's risk profile matches the client's appetite.

EDUCATIONAL FOCUS OF THIS AGENT:
    Unlike the Market Data Agent (pure data fetch), this agent demonstrates
    how LLMs ADD VALUE over raw data tools:
        - Raw tool output: "annualized_volatility_pct = 45.2"
        - Agent interpretation: "TSLA's 45% annualized volatility is roughly
          2.5x the S&P 500's typical 18% — this classifies it as HIGH risk,
          suitable only for investors with aggressive risk tolerance"

    This is the real power of LLM agents in finance: they bridge the gap
    between raw numbers and actionable narrative intelligence.

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import json
import logging
from typing import Any

# ── Third-party: LangChain ─────────────────────────────────────────────────
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, ToolMessage

# ── Internal imports ───────────────────────────────────────────────────────
from core.config import settings, FinancialAnalysisState
from tools.financial_tools import calculate_risk_metrics, ALL_RISK_TOOLS

logger = logging.getLogger(__name__)


# =============================================================================
# AGENT SYSTEM PROMPT
# =============================================================================

RISK_ANALYST_PROMPT = """You are a Senior Quantitative Risk Analyst at a top-tier investment bank.

You have 15 years of experience analyzing equity risk for institutional portfolios.
You specialize in statistical risk metrics and know how to interpret them for 
different types of investors.

RESPONSIBILITIES:
1. Call calculate_risk_metrics to get quantitative data
2. Interpret what those numbers MEAN for an investor
3. Identify key risk factors and red flags
4. Provide a risk rating: LOW / MEDIUM / HIGH / VERY HIGH

INTERPRETATION GUIDELINES:
- Volatility > 40%: Very high risk, suitable for aggressive investors only
- Volatility 20-40%: Moderate-high risk, suitable for growth investors
- Volatility < 20%: Lower risk, suitable for conservative investors
- Beta > 1.5: Highly sensitive to market downturns
- Beta 0.8-1.2: Market-correlated, typical equity
- Beta < 0.7: Defensive stock, good for hedging
- Sharpe > 2.0: Excellent risk-adjusted returns
- Sharpe 1.0-2.0: Acceptable risk-adjusted returns
- Sharpe < 1.0: Poor returns for the risk taken
- Max Drawdown > 50%: Extreme historical loss — be cautious
- VaR (daily, 95%): Expected maximum daily loss in normal conditions

OUTPUT FORMAT:
Provide exactly 3-5 bullet-point insights. Each insight should be:
- Specific (cite the actual number)  
- Interpreted (explain what it means)
- Actionable (what should an investor consider?)

Example: "Beta of 1.8 indicates TSLA moves 80% more than the market — in 
a 10% market correction, expect TSLA to drop approximately 18%"
"""


# =============================================================================
# RISK ANALYST AGENT NODE FUNCTION
# =============================================================================

def risk_analyst_agent_node(state: FinancialAnalysisState) -> dict:
    """
    Risk Analyst Agent: calculates and interprets risk metrics.

    KEY DIFFERENCE FROM MARKET DATA AGENT:
        After calling the risk tool, this agent uses a SECOND LLM call
        to INTERPRET the numbers. This is the "analysis" step that
        justifies having an LLM in this role.

    Args:
        state: Current state (must have 'ticker' and 'market_data' populated)

    Returns:
        Partial state update with 'risk_metrics' and 'risk_insights'
    """
    ticker       = state.get("ticker", "UNKNOWN").upper()
    company_name = state.get("company_name", ticker)

    logger.info(f"[RISK ANALYST] Starting risk analysis for {company_name} ({ticker})")

    # ── Initialize LLM with risk tools ────────────────────────────────────
    llm = ChatOpenAI(
        model=settings.llm_model,
        temperature=settings.analyst_temperature,
        api_key=settings.openai_api_key,
    ).bind_tools(ALL_RISK_TOOLS)

    # ── Step 1: Fetch risk metrics via tool call ───────────────────────────
    messages = [
        SystemMessage(content=RISK_ANALYST_PROMPT),
        HumanMessage(
            content=(
                f"Analyze the risk profile for {company_name} (ticker: {ticker}).\n"
                f"First, call calculate_risk_metrics to get the quantitative data.\n"
                f"Context from market data: Current price = ${state.get('market_data', {}).get('current_price', 'N/A')}, "
                f"Market cap = ${state.get('market_data', {}).get('market_cap', 'N/A'):,.0f}"
            )
        ),
    ]

    risk_metrics = {}       # Will be populated from tool call
    max_iterations = 3      # This agent needs at most 2 turns: call + interpret

    for iteration in range(max_iterations):
        response = llm.invoke(messages)

        if not response.tool_calls:
            # LLM is done calling tools — its text is the risk analysis
            logger.info("[RISK ANALYST] Analysis complete")
            break

        messages.append(response)  # Maintain conversation history

        for tool_call in response.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"]

            logger.info(f"[RISK ANALYST] Calling tool: {tool_name}({tool_args})")

            if tool_name == "calculate_risk_metrics":
                # Call the risk metrics calculation tool
                tool_result = calculate_risk_metrics.invoke(tool_args)
                risk_metrics = tool_result  # Capture for state update

            else:
                tool_result = {"error": f"Unknown tool: {tool_name}"}

            # Return tool result to LLM
            messages.append(
                ToolMessage(
                    content=json.dumps(tool_result, default=str),
                    tool_call_id=tool_call["id"],
                )
            )

    # ── Step 2: Extract the LLM's text interpretation ─────────────────────
    # The final non-tool response from the LLM contains the risk insights
    # We look for the last message with text content (not a tool call)
    risk_analysis_text = ""
    for msg in reversed(messages):
        # Check if this is an AI message with text content (not a tool call)
        if hasattr(msg, "content") and isinstance(msg.content, str) and msg.content:
            risk_analysis_text = msg.content
            break

    # ── Step 3: Parse insights into a list ────────────────────────────────
    # Split the LLM's bullet-point text into individual insight strings
    # This makes it easier for the Report Writer to format them
    insights = []
    if risk_analysis_text:
        # Split by common list delimiters and clean up whitespace
        lines = risk_analysis_text.strip().split("\n")
        for line in lines:
            cleaned = line.strip().lstrip("•-*123456789. ")  # Remove bullets/numbers
            if len(cleaned) > 20:   # Filter out very short lines (headers, etc.)
                insights.append(cleaned)

    # Fallback: if parsing failed, use the raw text as one insight
    if not insights and risk_analysis_text:
        insights = [risk_analysis_text]

    logger.info(f"[RISK ANALYST] Generated {len(insights)} risk insights")
    logger.info(f"[RISK ANALYST] Risk level: {risk_metrics.get('risk_level', 'Unknown')}")

    return {
        "risk_metrics"  : risk_metrics,
        "risk_insights" : insights,         # Appended to state via operator.add reducer
        "agent_steps"   : [
            f"RISK_ANALYST: vol={risk_metrics.get('annualized_volatility_pct', 'N/A')}%, "
            f"beta={risk_metrics.get('beta', 'N/A')}, "
            f"sharpe={risk_metrics.get('sharpe_ratio', 'N/A')}, "
            f"risk={risk_metrics.get('risk_level', 'N/A')}"
        ],
    }