"""
=============================================================================
agents/report_writer_agent.py — Report Writer Specialist Agent
=============================================================================

WHAT THIS AGENT DOES:
    The Report Writer is the FINAL agent in the pipeline.
    It receives the COMPLETE state (all prior agents' outputs) and synthesizes
    everything into a professional investment brief.

    Real-world analogy: The senior equity research analyst who reads all
    the quant team's data, the risk team's models, and the fundamental
    team's valuation work — then writes the client-facing research note.

WHY THIS IS THE HARDEST AGENT TO BUILD WELL:
    Writing good financial reports is challenging because:
    1. Must accurately represent numbers from multiple sources
    2. Must be logically consistent (can't say "low risk" in one paragraph
       and "highly volatile" in another without explanation)
    3. Must give a CLEAR, defensible recommendation
    4. Must be readable by a non-expert client

WHAT MAKES THIS AGENT DIFFERENT FROM THE OTHERS:
    - NO TOOL CALLS — this agent only uses the LLM, no external tools
    - Higher temperature (0.4 vs 0.1) — allows more natural prose
    - Receives the FULL state — most context-aware agent
    - Outputs two things: a report AND a structured recommendation

OUTPUT STRUCTURE:
    ┌─────────────────────────────────────────────────────────────┐
    │ INVESTMENT BRIEF: [Company Name]                            │
    │                                                             │
    │ EXECUTIVE SUMMARY    — 2-3 sentence overview               │
    │                                                             │
    │ MARKET DATA          — Current price, trend, volume        │
    │                                                             │
    │ RISK ASSESSMENT      — Volatility, Beta, VaR summary       │
    │                                                             │
    │ FUNDAMENTAL ANALYSIS — Valuation, margins, health          │
    │                                                             │
    │ INVESTMENT THESIS    — Bull case, bear case                 │
    │                                                             │
    │ RECOMMENDATION       — BUY / HOLD / SELL + confidence      │
    └─────────────────────────────────────────────────────────────┘

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import json
import logging
import re                               # For parsing recommendation from text

# ── Third-party: LangChain ─────────────────────────────────────────────────
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage

# ── Internal imports ───────────────────────────────────────────────────────
from core.config import settings, FinancialAnalysisState

logger = logging.getLogger(__name__)


# =============================================================================
# AGENT SYSTEM PROMPT
# =============================================================================

REPORT_WRITER_PROMPT = """You are the Head of Equity Research at a prestigious investment bank.

You have received analysis from three specialist teams:
- Market Data Team: current price, volume, 52-week range
- Risk Analytics Team: volatility, beta, Sharpe ratio, VaR
- Fundamental Analysis Team: valuation ratios, margins, debt, growth

Your job is to synthesize all of this into a professional, client-ready 
investment brief that non-expert investors can understand.

REPORT STRUCTURE (follow this EXACTLY):
---
## INVESTMENT BRIEF: [COMPANY NAME] ([TICKER])
*Generated: [DATE]*

### EXECUTIVE SUMMARY
[2-3 sentences: What kind of company is this? What's the key takeaway for an investor?]

### MARKET SNAPSHOT
[Current price, day change, 52-week position, market cap — use the numbers provided]

### RISK PROFILE
[Summarize volatility, beta, Sharpe, VaR in plain English — what does risk mean for THIS investor?]

### FUNDAMENTAL ANALYSIS
[Valuation (expensive/cheap?), profitability, growth trajectory, balance sheet strength]

### INVESTMENT THESIS
**Bull Case:** [2-3 reasons why the stock could outperform]
**Bear Case:** [2-3 risks that could hurt the investment]

### RECOMMENDATION
**[BUY / HOLD / SELL]** | Confidence: [HIGH / MEDIUM / LOW]

*Rationale:* [1-2 sentences explaining the recommendation]

*Suitable for:* [Type of investor this stock is appropriate for]

*Disclaimer: This is AI-generated analysis for educational purposes only. 
Not financial advice. Always consult a licensed financial advisor.*
---

TONE: Professional but accessible. Avoid jargon without explanation.
NUMBERS: Always cite specific numbers from the data provided.
BALANCE: Acknowledge both strengths and weaknesses.
"""


# =============================================================================
# REPORT WRITER AGENT NODE FUNCTION
# =============================================================================

def report_writer_agent_node(state: FinancialAnalysisState) -> dict:
    """
    Report Writer Agent: synthesizes all analysis into final investment brief.

    KEY PATTERN — FULL STATE CONTEXT INJECTION:
        This agent receives the COMPLETE outputs of all previous agents:
            - market_data (prices, company info)
            - risk_metrics (vol, beta, VaR, Sharpe)
            - risk_insights (interpreted risk text)
            - fundamental_data (P/E, margins, debt)
            - fundamental_insights (interpreted valuation text)

        We format ALL of this into a structured prompt so the LLM has
        complete context to write an informed, accurate report.

    Args:
        state: Complete pipeline state — all agents' outputs are available

    Returns:
        Final state update with 'final_report' and 'recommendation'
    """
    ticker       = state.get("ticker", "UNKNOWN").upper()
    company_name = state.get("company_name", ticker)

    logger.info(f"[REPORT WRITER] Synthesizing final report for {company_name}")

    # ── Initialize LLM (no tools needed — pure synthesis) ─────────────────
    # Higher temperature for more natural prose in the report
    llm = ChatOpenAI(
        model=settings.llm_model,
        temperature=settings.writer_temperature,    # 0.4: readable but not too creative
        api_key=settings.openai_api_key,
        # No bind_tools() — this agent doesn't call any tools
    )

    # ── Build comprehensive context from all prior agents ─────────────────
    market_data  = state.get("market_data", {})
    risk_metrics = state.get("risk_metrics", {})
    fund_data    = state.get("fundamental_data", {})

    # Format insights as readable text blocks
    risk_insights_text = "\n".join(
        f"  • {insight}" for insight in state.get("risk_insights", [])
    ) or "  • No risk insights available"

    fundamental_insights_text = "\n".join(
        f"  • {insight}" for insight in state.get("fundamental_insights", [])
    ) or "  • No fundamental insights available"

    # ── Assemble the comprehensive data brief for the LLM ─────────────────
    # This is the "input document" the report writer reads before writing
    data_brief = f"""
COMPANY OVERVIEW:
  Name: {company_name}
  Ticker: {ticker}
  Sector: {market_data.get('sector', 'N/A')}
  Industry: {market_data.get('industry', 'N/A')}
  Description: {market_data.get('description', 'N/A')[:200]}

MARKET DATA:
  Current Price: ${market_data.get('current_price', 'N/A')}
  Daily Change: ${market_data.get('price_change', 'N/A')} ({market_data.get('price_change_pct', 'N/A')}%)
  Day Range: ${market_data.get('day_low', 'N/A')} - ${market_data.get('day_high', 'N/A')}
  52-Week Range: ${market_data.get('week_52_low', 'N/A')} - ${market_data.get('week_52_high', 'N/A')}
  Volume: {market_data.get('volume', 'N/A'):,} (Avg: {market_data.get('avg_volume', 'N/A'):,})
  Market Cap: ${market_data.get('market_cap', 0):,.0f}

RISK METRICS:
  Risk Level: {risk_metrics.get('risk_level', 'N/A')}
  Annualized Volatility: {risk_metrics.get('annualized_volatility_pct', 'N/A')}%
  Beta: {risk_metrics.get('beta', 'N/A')}
  Sharpe Ratio: {risk_metrics.get('sharpe_ratio', 'N/A')}
  Value at Risk (95%, daily): {risk_metrics.get('var_95_daily_pct', 'N/A')}%
  Max Drawdown (1yr): {risk_metrics.get('max_drawdown_pct', 'N/A')}%
  Avg Daily Return: {risk_metrics.get('avg_daily_return_pct', 'N/A')}%

RISK ANALYST INSIGHTS:
{risk_insights_text}

FUNDAMENTAL METRICS:
  Valuation:
    P/E Ratio (TTM): {fund_data.get('pe_ratio', 'N/A')}
    Forward P/E: {fund_data.get('forward_pe', 'N/A')}
    PEG Ratio: {fund_data.get('peg_ratio', 'N/A')}
    Price/Book: {fund_data.get('pb_ratio', 'N/A')}
    EPS (TTM): ${fund_data.get('eps_ttm', 'N/A')}
    EPS (Forward): ${fund_data.get('eps_forward', 'N/A')}
  Profitability:
    Gross Margin: {fund_data.get('gross_margin_pct', 'N/A')}%
    Operating Margin: {fund_data.get('operating_margin_pct', 'N/A')}%
    Net Margin: {fund_data.get('net_margin_pct', 'N/A')}%
    ROE: {fund_data.get('roe_pct', 'N/A')}%
    ROA: {fund_data.get('roa_pct', 'N/A')}%
  Growth:
    Revenue Growth (YoY): {fund_data.get('revenue_growth_pct', 'N/A')}%
    Earnings Growth (YoY): {fund_data.get('earnings_growth_pct', 'N/A')}%
  Financial Health:
    Debt/Equity: {fund_data.get('debt_to_equity', 'N/A')}
    Current Ratio: {fund_data.get('current_ratio', 'N/A')}
    Quick Ratio: {fund_data.get('quick_ratio', 'N/A')}
    Free Cash Flow: ${fund_data.get('free_cash_flow_usd', 0):,.0f}
  Dividend:
    Dividend Yield: {fund_data.get('dividend_yield_pct', 'N/A')}%

FUNDAMENTAL ANALYST INSIGHTS:
{fundamental_insights_text}

ORIGINAL ANALYSIS REQUEST: {state.get('analysis_request', 'General investment analysis')}
"""

    # ── Single LLM Call — No Tool Loop Needed ─────────────────────────────
    # This agent does a single, comprehensive LLM call.
    # Unlike analyst agents, the report writer doesn't need to call tools —
    # it just needs to synthesize the data we've already collected.
    messages = [
        SystemMessage(content=REPORT_WRITER_PROMPT),
        HumanMessage(
            content=(
                f"Write the investment brief using the following data:\n\n"
                f"{data_brief}"
            )
        ),
    ]

    logger.info("[REPORT WRITER] Calling LLM for report synthesis...")
    response = llm.invoke(messages)
    final_report = response.content

    # ── Extract Recommendation from Report ────────────────────────────────
    # Parse the recommendation (BUY/HOLD/SELL) from the report text
    # This structured field is used by the API and UI
    recommendation = "HOLD"     # Default fallback
    confidence     = "MEDIUM"   # Default fallback

    # Search for recommendation pattern: "**BUY**" or "**HOLD**" or "**SELL**"
    # Case-insensitive, handle bold markdown formatting
    rec_pattern = r'\*{0,2}(BUY|HOLD|SELL)\*{0,2}'
    rec_match   = re.search(rec_pattern, final_report, re.IGNORECASE)
    if rec_match:
        recommendation = rec_match.group(1).upper()

    # Search for confidence level
    conf_pattern = r'Confidence:\s*\*{0,2}(HIGH|MEDIUM|LOW)\*{0,2}'
    conf_match   = re.search(conf_pattern, final_report, re.IGNORECASE)
    if conf_match:
        confidence = conf_match.group(1).upper()

    full_recommendation = f"{recommendation} | Confidence: {confidence}"
    logger.info(f"[REPORT WRITER] Report complete. Recommendation: {full_recommendation}")

    return {
        "final_report"      : final_report,
        "recommendation"    : full_recommendation,
        "analysis_complete" : True,             # Signal to supervisor that we're done
        "agent_steps"       : [
            f"REPORT_WRITER: Generated {len(final_report)} char report. "
            f"Recommendation: {full_recommendation}"
        ],
    }