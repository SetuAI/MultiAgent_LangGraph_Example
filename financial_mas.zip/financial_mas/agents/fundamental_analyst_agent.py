"""
=============================================================================
agents/fundamental_analyst_agent.py — Fundamental Analyst Specialist Agent
=============================================================================

WHAT THIS AGENT DOES:
    This agent performs fundamental/value analysis — the core of Warren
    Buffett-style investing. It answers the question:
        "Is this company financially healthy and priced fairly?"

    Two types of analysis performed:
    1. VALUATION ANALYSIS — Is the stock cheap or expensive vs. its earnings?
    2. FINANCIAL HEALTH ANALYSIS — Is the business strong enough to sustain?

FUNDAMENTAL VS TECHNICAL ANALYSIS:
    ┌──────────────────────────────────────────────────────────────┐
    │ FUNDAMENTAL ANALYSIS             TECHNICAL ANALYSIS          │
    │ "What is it WORTH?"              "Where is the price GOING?" │
    │                                                              │
    │ P/E ratio, EPS growth            Moving averages, RSI        │
    │ Revenue trends                   Volume patterns             │
    │ Debt levels, margins             Chart patterns              │
    │ Management quality               Momentum indicators         │
    │ Long-term (months-years)         Short-term (days-weeks)     │
    └──────────────────────────────────────────────────────────────┘

    Our pipeline does BOTH: risk_analyst handles technical/statistical,
    fundamental_analyst handles the balance sheet and valuation.

KEY VALUATION FRAMEWORKS USED:
    1. P/E relative to industry average (is it overpriced?)
    2. PEG ratio (does growth justify the P/E premium?)
    3. Margin trends (is profitability improving or deteriorating?)
    4. Debt sustainability (can it survive a recession?)
    5. Free cash flow (is the business generating real cash?)

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import json
import logging
from typing import Any

# ── Third-party: LangChain ─────────────────────────────────────────────────
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage, ToolMessage

# ── Internal imports ───────────────────────────────────────────────────────
from core.config import settings, FinancialAnalysisState
from tools.financial_tools import fetch_fundamental_data, ALL_FUNDAMENTAL_TOOLS

logger = logging.getLogger(__name__)


# =============================================================================
# AGENT SYSTEM PROMPT
# =============================================================================

FUNDAMENTAL_ANALYST_PROMPT = """You are a Senior Fundamental Analyst at a value-oriented hedge fund.

You have deep expertise in financial statement analysis, DCF valuation, and 
comparative company analysis across all major sectors.

RESPONSIBILITIES:
1. Call fetch_fundamental_data to retrieve financial metrics
2. Assess VALUATION: Is the stock cheap, fair value, or expensive?
3. Assess FINANCIAL HEALTH: Is the business strong, stable, or fragile?
4. Identify key catalysts (positive) and risks (negative)

VALUATION BENCHMARKS (sector-adjusted):
- P/E < 15: Potentially undervalued (check why — is growth slowing?)
- P/E 15-25: Fair value for moderate-growth companies
- P/E 25-40: Growth premium — justified only if growth > 15%
- P/E > 40: Expensive — requires exceptional growth to justify
- PEG < 1.0: Stock may be undervalued relative to its growth (buy signal)
- PEG > 2.0: Growth priced in generously (caution)

FINANCIAL HEALTH BENCHMARKS:
- Net Margin > 20%: Excellent profitability (pricing power present)
- Net Margin 10-20%: Good profitability
- Net Margin < 5%: Low margin — competitive pressure or structural issues
- Debt/Equity < 0.5: Conservative — strong balance sheet
- Debt/Equity 0.5-1.5: Moderate leverage — manageable
- Debt/Equity > 2.0: High leverage — vulnerable in rate hikes
- Free Cash Flow > 0: Company is generating real cash (not just accounting profit)
- ROE > 15%: Management is using capital efficiently

ANALYSIS STRUCTURE:
Provide EXACTLY 4-6 insights covering:
1. One valuation insight (expensive/cheap/fair + why)
2. One profitability insight (margins, trends)
3. One growth insight (revenue/earnings trajectory)
4. One financial health insight (debt, liquidity)
5. Optional: dividend or cash flow insight

Always cite the actual numbers in your insights.
"""


# =============================================================================
# FUNDAMENTAL ANALYST AGENT NODE FUNCTION
# =============================================================================

def fundamental_analyst_agent_node(state: FinancialAnalysisState) -> dict:
    """
    Fundamental Analyst Agent: fetches and interprets valuation & financial metrics.

    CONTEXT INJECTION:
        Unlike the Risk Agent (which only needed the ticker), this agent also
        injects the MARKET DATA collected earlier. This gives it context:
        - Current price (needed to validate P/E calculations)
        - Market cap (helps frame the company's size)
        - Sector (helps choose appropriate valuation benchmarks)

        This is a key MAS pattern: agents share context via shared state.

    Args:
        state: Current state (must have ticker, market_data, risk_metrics)

    Returns:
        Partial state update with 'fundamental_data' and 'fundamental_insights'
    """
    ticker       = state.get("ticker", "UNKNOWN").upper()
    company_name = state.get("company_name", ticker)
    market_data  = state.get("market_data", {})
    risk_metrics = state.get("risk_metrics", {})

    logger.info(f"[FUNDAMENTAL ANALYST] Starting fundamental analysis for {company_name}")

    # ── Initialize LLM with fundamental tools ─────────────────────────────
    llm = ChatOpenAI(
        model=settings.llm_model,
        temperature=settings.analyst_temperature,
        api_key=settings.openai_api_key,
    ).bind_tools(ALL_FUNDAMENTAL_TOOLS)

    # ── Build context-rich prompt ──────────────────────────────────────────
    # Inject previously collected data into the prompt so the LLM has
    # full context when interpreting fundamental metrics
    context_summary = (
        f"Company: {company_name} ({ticker})\n"
        f"Sector: {market_data.get('sector', 'Unknown')}\n"
        f"Industry: {market_data.get('industry', 'Unknown')}\n"
        f"Current Price: ${market_data.get('current_price', 'N/A')}\n"
        f"Market Cap: ${market_data.get('market_cap', 0):,.0f}\n"
        f"52-Week Range: ${market_data.get('week_52_low', 'N/A')} - ${market_data.get('week_52_high', 'N/A')}\n"
        f"Risk Assessment: {risk_metrics.get('risk_level', 'Unknown')} risk, "
        f"Beta={risk_metrics.get('beta', 'N/A')}"
    )

    messages = [
        SystemMessage(content=FUNDAMENTAL_ANALYST_PROMPT),
        HumanMessage(
            content=(
                f"Perform fundamental analysis for {company_name} ({ticker}).\n\n"
                f"CONTEXT FROM PREVIOUS AGENTS:\n{context_summary}\n\n"
                f"Call fetch_fundamental_data to retrieve the detailed financials, "
                f"then provide your fundamental analysis insights."
            )
        ),
    ]

    # ── Agentic tool-calling loop ──────────────────────────────────────────
    fundamental_data = {}
    max_iterations   = 3

    for iteration in range(max_iterations):
        response = llm.invoke(messages)

        if not response.tool_calls:
            logger.info("[FUNDAMENTAL ANALYST] Analysis complete")
            break

        messages.append(response)

        for tool_call in response.tool_calls:
            tool_name = tool_call["name"]
            tool_args = tool_call["args"]

            logger.info(f"[FUNDAMENTAL ANALYST] Calling tool: {tool_name}({tool_args})")

            if tool_name == "fetch_fundamental_data":
                tool_result   = fetch_fundamental_data.invoke(tool_args)
                fundamental_data = tool_result  # Capture raw data for state
            else:
                tool_result = {"error": f"Unknown tool: {tool_name}"}

            messages.append(
                ToolMessage(
                    content=json.dumps(tool_result, default=str),
                    tool_call_id=tool_call["id"],
                )
            )

    # ── Extract the LLM's analysis text ───────────────────────────────────
    analysis_text = ""
    for msg in reversed(messages):
        if hasattr(msg, "content") and isinstance(msg.content, str) and msg.content:
            analysis_text = msg.content
            break

    # ── Parse insights into a list ────────────────────────────────────────
    insights = []
    if analysis_text:
        lines = analysis_text.strip().split("\n")
        for line in lines:
            cleaned = line.strip().lstrip("•-*123456789. ")
            if len(cleaned) > 20:
                insights.append(cleaned)

    if not insights and analysis_text:
        insights = [analysis_text]

    logger.info(
        f"[FUNDAMENTAL ANALYST] Generated {len(insights)} insights. "
        f"PE={fundamental_data.get('pe_ratio', 'N/A')}, "
        f"Net Margin={fundamental_data.get('net_margin_pct', 'N/A')}%"
    )

    return {
        "fundamental_data"     : fundamental_data,
        "fundamental_insights" : insights,      # Appended via operator.add
        "agent_steps"          : [
            f"FUNDAMENTAL_ANALYST: PE={fundamental_data.get('pe_ratio', 'N/A')}, "
            f"EPS={fundamental_data.get('eps_ttm', 'N/A')}, "
            f"NetMargin={fundamental_data.get('net_margin_pct', 'N/A')}%, "
            f"D/E={fundamental_data.get('debt_to_equity', 'N/A')}"
        ],
    }