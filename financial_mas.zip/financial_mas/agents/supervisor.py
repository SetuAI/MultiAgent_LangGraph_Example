"""
=============================================================================
agents/supervisor.py — Supervisor Agent (The Orchestrator)
=============================================================================

WHY A SUPERVISOR AGENT?
    In a multi-agent system, SOMEONE needs to be in charge.
    The Supervisor is like a senior analyst at an investment bank:
        - Receives the client request
        - Decides which specialists to consult (and in what order)
        - Monitors progress
        - Decides when enough analysis has been done
        - Routes to the final report writer

SUPERVISOR DESIGN PATTERN IN LANGGRAPH:
    The Supervisor uses a "conditional edge" pattern:
    ┌─────────────────────────────────────────────────────────────┐
    │  After EVERY agent completes, the graph calls:              │
    │      route_after_agent(state) → next_node_name             │
    │                                                             │
    │  The supervisor updates state["next_agent"] to either:     │
    │      - Another agent name  → continue analysis             │
    │      - "END"               → we're done, stop the graph    │
    └─────────────────────────────────────────────────────────────┘

EXECUTION ORDER (hardcoded for educational clarity):
    1. market_data_agent     — Get raw price & company data
    2. risk_analyst_agent    — Calculate risk metrics
    3. fundamental_analyst   — Calculate valuation metrics
    4. report_writer_agent   — Synthesize everything into a report
    5. END                   — Pipeline complete

    In production, you'd make this dynamic (supervisor LLM chooses order),
    but for teaching purposes, a fixed order is clearer to explain.

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import logging                          # Structured logging
from typing import Literal              # For strict type hints on return values

# ── Third-party: LangChain / LangGraph ────────────────────────────────────
from langchain_openai import ChatOpenAI         # OpenAI LLM wrapper
from langchain_core.messages import SystemMessage, HumanMessage  # Message types

# ── Internal imports ───────────────────────────────────────────────────────
from core.config import settings, FinancialAnalysisState, AgentNames

logger = logging.getLogger(__name__)


# =============================================================================
# SUPERVISOR NODE FUNCTION
# =============================================================================
# In LangGraph, a "node" is just a function:
#   Input:  current state (FinancialAnalysisState)
#   Output: partial state update (dict)

def supervisor_node(state: FinancialAnalysisState) -> dict:
    """
    Supervisor node: decides which agent runs next in the pipeline.

    DECISION LOGIC:
        The supervisor checks what data has already been collected
        and routes to the next logical step:

        No market data yet?        → Go to market_data_agent
        No risk metrics yet?       → Go to risk_analyst_agent
        No fundamental data yet?   → Go to fundamental_analyst_agent
        All data collected?        → Go to report_writer_agent
        Report written?            → END the graph

    Args:
        state: Current shared state containing all agent outputs so far

    Returns:
        Dict with updated `next_agent` field — LangGraph reads this to
        determine which node (conditional edge) to visit next.
    """
    logger.info("[SUPERVISOR] Evaluating pipeline progress...")

    # ── Log current state for debugging ───────────────────────────────────
    # This is invaluable during development to see what data exists
    has_market_data      = bool(state.get("market_data"))
    has_risk_metrics     = bool(state.get("risk_metrics"))
    has_fundamental_data = bool(state.get("fundamental_data"))
    has_report           = bool(state.get("final_report"))

    logger.info(
        f"[SUPERVISOR] State: market={has_market_data}, "
        f"risk={has_risk_metrics}, fundamental={has_fundamental_data}, "
        f"report={has_report}"
    )

    # ── Routing Logic (waterfall / sequential pattern) ─────────────────────
    # This is a simple deterministic router. Each check represents one stage
    # of the pipeline. We route to the FIRST stage that hasn't run yet.

    if not has_market_data:
        # Stage 1: No price data yet — start with market data collection
        next_agent = AgentNames.MARKET_DATA_AGENT
        log_msg    = "Routing to Market Data Agent — need price data first"

    elif not has_risk_metrics:
        # Stage 2: Have price data, but no risk analysis yet
        next_agent = AgentNames.RISK_ANALYST_AGENT
        log_msg    = "Routing to Risk Analyst — calculating volatility & VaR"

    elif not has_fundamental_data:
        # Stage 3: Have price + risk data, but no fundamentals yet
        next_agent = AgentNames.FUNDAMENTAL_ANALYST
        log_msg    = "Routing to Fundamental Analyst — evaluating valuation"

    elif not has_report:
        # Stage 4: Have all data — time to write the final report
        next_agent = AgentNames.REPORT_WRITER
        log_msg    = "Routing to Report Writer — synthesizing final brief"

    else:
        # Stage 5: Everything is done!
        next_agent = AgentNames.END
        log_msg    = "Pipeline complete — all agents have finished"

    logger.info(f"[SUPERVISOR] Decision: {log_msg}")

    # Return ONLY the fields we're updating — LangGraph merges this with existing state
    return {
        "next_agent"  : next_agent,
        "agent_steps" : [f"SUPERVISOR → {next_agent}: {log_msg}"],  # Appended (see reducer)
    }


# =============================================================================
# CONDITIONAL ROUTER FUNCTION
# =============================================================================
# This function is used as the "condition" on conditional edges in the graph.
# LangGraph calls this after every node to decide which edge to follow.
#
# IMPORTANT: This is NOT a node — it's a router called by LangGraph internally.
# It must return a string matching one of the edge target names.

def route_to_next_agent(
    state: FinancialAnalysisState,
) -> Literal[
    "market_data_agent",
    "risk_analyst_agent",
    "fundamental_analyst_agent",
    "report_writer_agent",
    "__end__",      # LangGraph's special constant for termination
]:
    """
    Conditional router: reads next_agent from state and returns the node name.

    WHY A SEPARATE FUNCTION?
        LangGraph's add_conditional_edges() requires a function that maps
        state → node name. We could put logic here, but it's cleaner to
        keep routing logic in supervisor_node and just read the decision here.

    Returns:
        String name of the next node to execute, or "__end__" to stop.
    """
    next_agent = state.get("next_agent", AgentNames.END)

    # Map AgentNames constants to LangGraph node name strings
    # Note: AgentNames.END = "END" but LangGraph uses "__end__" internally
    if next_agent == AgentNames.END:
        return "__end__"            # LangGraph's built-in END constant

    return next_agent               # Any other agent name maps directly