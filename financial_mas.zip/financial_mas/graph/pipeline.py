"""
=============================================================================
graph/pipeline.py — LangGraph Multi-Agent Pipeline (The Heart of the System)
=============================================================================

THIS IS THE MOST IMPORTANT FILE IN THE ENTIRE PROJECT.
Read it carefully — this is where LangGraph orchestration happens.

WHAT IS LANGGRAPH?
    LangGraph is a framework for building stateful, multi-step LLM workflows.
    It models your agent pipeline as a DIRECTED GRAPH where:
        - NODES = agent functions (or tool functions)
        - EDGES = connections between agents (who can call whom?)
        - CONDITIONAL EDGES = smart routing ("go to agent X if condition Y")
        - STATE = shared memory dict passed through every node

    Think of it like a flowchart that comes to life.

THE GRAPH WE'RE BUILDING:
    ┌─────────────────────────────────────────────────────────────────┐
    │                                                                  │
    │  START → supervisor → [route] → market_data_agent              │
    │                                        ↓                        │
    │               supervisor ←────────────┘                        │
    │                   ↓                                             │
    │              [route] → risk_analyst_agent                       │
    │                                ↓                                │
    │               supervisor ←────┘                                 │
    │                   ↓                                             │
    │              [route] → fundamental_analyst_agent                │
    │                                        ↓                        │
    │               supervisor ←────────────┘                        │
    │                   ↓                                             │
    │              [route] → report_writer_agent → END               │
    │                                                                  │
    └──────────────────────────────────────────────────────────────────┘

    The supervisor runs AFTER EVERY agent. This "hub-and-spoke" pattern
    means the supervisor always controls what happens next.

STATE FLOW EXAMPLE (ticker = "AAPL"):
    t=0  state = {ticker: "AAPL", market_data: {}, risk_metrics: {}, ...}
    t=1  supervisor sees no market_data → sets next_agent="market_data_agent"
    t=2  market_data_agent fills market_data → state updated
    t=3  supervisor sees market_data ✓, no risk_metrics → next_agent="risk_analyst"
    t=4  risk_analyst fills risk_metrics, risk_insights → state updated
    t=5  supervisor sees risk_metrics ✓, no fundamental_data → next="fundamental_analyst"
    t=6  fundamental_analyst fills fundamental_data, fundamental_insights
    t=7  supervisor sees all data ✓, no report → next_agent="report_writer"
    t=8  report_writer fills final_report, recommendation, analysis_complete=True
    t=9  supervisor sees analysis_complete → next_agent="END"
    t=10 graph terminates, returns final state

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import logging

# ── Third-party: LangGraph ─────────────────────────────────────────────────
from langgraph.graph import StateGraph, START, END
# StateGraph  — the main class for building agent graphs
# START       — special constant representing the entry point of the graph
# END         — special constant representing graph termination

# ── Internal: State schema ─────────────────────────────────────────────────
from core.config import FinancialAnalysisState, AgentNames

# ── Internal: All agent node functions ────────────────────────────────────
# Each of these is a Python function: state → partial_state_update
from agents.supervisor import supervisor_node, route_to_next_agent
from agents.market_data_agent import market_data_agent_node
from agents.risk_analyst_agent import risk_analyst_agent_node
from agents.fundamental_analyst_agent import fundamental_analyst_agent_node
from agents.report_writer_agent import report_writer_agent_node

logger = logging.getLogger(__name__)


# =============================================================================
# GRAPH CONSTRUCTION FUNCTION
# =============================================================================
# We wrap graph construction in a function so we can call it fresh each time.
# This also makes it easy to test different graph configurations.

def build_financial_analysis_graph() -> StateGraph:
    """
    Construct and compile the LangGraph multi-agent pipeline.

    GRAPH CONSTRUCTION STEPS:
        1. Create a StateGraph with our state schema
        2. Add all agent nodes
        3. Set the entry point
        4. Add normal (unconditional) edges
        5. Add conditional edges (where supervisor makes routing decisions)
        6. Compile the graph

    Returns:
        A compiled LangGraph graph ready to execute with .invoke() or .stream()
    """
    logger.info("[GRAPH] Building Financial Analysis Multi-Agent Graph...")

    # ── Step 1: Create the StateGraph ─────────────────────────────────────
    # StateGraph takes our state TYPE as a parameter.
    # This tells LangGraph what fields exist and how to merge updates.
    # The Annotated[list, operator.add] fields we defined get automatically
    # merged (appended) — LangGraph handles this via the type annotations.
    graph_builder = StateGraph(FinancialAnalysisState)

    # ── Step 2: Add Nodes ──────────────────────────────────────────────────
    # .add_node(name, function) registers a node in the graph.
    # The name must match what the router returns (AgentNames constants).
    # The function is called with the current state and must return a dict.

    # The Supervisor — orchestrates the entire pipeline
    graph_builder.add_node(
        AgentNames.SUPERVISOR,          # Node name: "supervisor"
        supervisor_node                 # Function to call when this node runs
    )

    # Market Data Agent — fetches prices and company info
    graph_builder.add_node(
        AgentNames.MARKET_DATA_AGENT,   # Node name: "market_data_agent"
        market_data_agent_node
    )

    # Risk Analyst Agent — calculates volatility, beta, VaR
    graph_builder.add_node(
        AgentNames.RISK_ANALYST_AGENT,  # Node name: "risk_analyst_agent"
        risk_analyst_agent_node
    )

    # Fundamental Analyst Agent — evaluates valuation and financial health
    graph_builder.add_node(
        AgentNames.FUNDAMENTAL_ANALYST, # Node name: "fundamental_analyst_agent"
        fundamental_analyst_agent_node
    )

    # Report Writer Agent — synthesizes everything into the final brief
    graph_builder.add_node(
        AgentNames.REPORT_WRITER,       # Node name: "report_writer_agent"
        report_writer_agent_node
    )

    # ── Step 3: Set Entry Point ────────────────────────────────────────────
    # START → supervisor: the graph ALWAYS begins at the supervisor.
    # The supervisor's first action is to check state and route accordingly.
    # This makes the supervisor the "main function" of the entire pipeline.
    graph_builder.add_edge(
        START,                          # Graph entry point (built-in constant)
        AgentNames.SUPERVISOR           # First node to execute
    )

    # ── Step 4: Add Return Edges (Agent → Supervisor) ──────────────────────
    # CRUCIAL PATTERN: After EVERY specialist agent completes, control returns
    # to the supervisor. This is the "hub-and-spoke" routing pattern.
    #
    # Why always return to supervisor?
    #   - Supervisor maintains visibility of the entire pipeline
    #   - Easy to add new agents without changing other agents
    #   - Supervisor can re-run agents if data is missing or wrong
    #   - Clean separation of concerns: agents analyze, supervisor routes

    # market_data_agent → supervisor (supervisor decides what's next)
    graph_builder.add_edge(
        AgentNames.MARKET_DATA_AGENT,   # Source node
        AgentNames.SUPERVISOR           # Destination node
    )

    # risk_analyst_agent → supervisor
    graph_builder.add_edge(
        AgentNames.RISK_ANALYST_AGENT,
        AgentNames.SUPERVISOR
    )

    # fundamental_analyst_agent → supervisor
    graph_builder.add_edge(
        AgentNames.FUNDAMENTAL_ANALYST,
        AgentNames.SUPERVISOR
    )

    # report_writer_agent → supervisor (supervisor will see complete=True → END)
    graph_builder.add_edge(
        AgentNames.REPORT_WRITER,
        AgentNames.SUPERVISOR
    )

    # ── Step 5: Add Conditional Edges (Supervisor → Next Agent) ───────────
    # add_conditional_edges(source, condition_fn, mapping) means:
    #   "After 'source' runs, call condition_fn(state) to get a string,
    #    then follow the edge whose key matches that string."
    #
    # The mapping dict translates condition_fn return values to node names.
    # "__end__" is LangGraph's internal name for the END constant.

    graph_builder.add_conditional_edges(
        AgentNames.SUPERVISOR,          # Source: conditional edges leave from here

        route_to_next_agent,            # Condition function: reads state["next_agent"]

        # Mapping: condition_fn return value → node to go to
        {
            AgentNames.MARKET_DATA_AGENT   : AgentNames.MARKET_DATA_AGENT,
            AgentNames.RISK_ANALYST_AGENT  : AgentNames.RISK_ANALYST_AGENT,
            AgentNames.FUNDAMENTAL_ANALYST : AgentNames.FUNDAMENTAL_ANALYST,
            AgentNames.REPORT_WRITER       : AgentNames.REPORT_WRITER,
            "__end__"                      : END,   # Route to END constant
        }
    )

    # ── Step 6: Compile the Graph ──────────────────────────────────────────
    # .compile() validates the graph structure and returns an executable object.
    # After compilation, the graph can be run with:
    #   - graph.invoke(initial_state)   → synchronous, returns final state
    #   - graph.stream(initial_state)   → streams each node's output as it runs
    #   - graph.astream(initial_state)  → async version of stream

    compiled_graph = graph_builder.compile()

    logger.info("[GRAPH] Graph compiled successfully!")
    logger.info(
        f"[GRAPH] Nodes: {list(graph_builder.nodes.keys()) if hasattr(graph_builder, 'nodes') else 'see graph'}"
    )

    return compiled_graph


# =============================================================================
# PIPELINE RUNNER — The main entry point for running a full analysis
# =============================================================================

def run_financial_analysis(
    ticker: str,
    analysis_request: str = "Provide a comprehensive investment analysis",
) -> dict:
    """
    Execute the full financial analysis pipeline for a given stock ticker.

    This is the main function you call to run the entire MAS pipeline.
    It handles:
        1. Building the graph (or using a cached version)
        2. Creating the initial state
        3. Running the graph to completion
        4. Returning the final state with all outputs

    Args:
        ticker:           Stock symbol (e.g., "AAPL", "MSFT", "TSLA", "NVDA")
        analysis_request: Optional custom instruction for the analysis focus

    Returns:
        Final state dictionary containing:
            - market_data: Raw price and company data
            - risk_metrics: Calculated risk metrics
            - risk_insights: Risk analyst's text insights
            - fundamental_data: Valuation and financial metrics
            - fundamental_insights: Fundamental analyst's text insights
            - final_report: Complete investment brief (Markdown)
            - recommendation: "BUY/HOLD/SELL | Confidence: HIGH/MEDIUM/LOW"
            - agent_steps: Chronological log of all agent actions
            - errors: Any non-fatal errors encountered
    """
    logger.info(f"[PIPELINE] Starting full analysis for ticker: {ticker}")
    logger.info(f"[PIPELINE] Analysis request: {analysis_request}")

    # ── Build the graph ────────────────────────────────────────────────────
    # In production, you'd cache this at module level to avoid rebuilding.
    # For education, we rebuild each time to keep it transparent.
    graph = build_financial_analysis_graph()

    # ── Create Initial State ───────────────────────────────────────────────
    # This is the "blank baton" that gets passed through all agents.
    # We populate ONLY the input fields — all output fields start empty/default.
    initial_state = {
        # Input fields (provided by user)
        "ticker"           : ticker.upper(),
        "analysis_request" : analysis_request,

        # Output fields (filled by agents as pipeline runs)
        "company_name"          : "",
        "market_data"           : {},
        "risk_metrics"          : {},
        "risk_insights"         : [],       # Empty list — operator.add will append
        "fundamental_data"      : {},
        "fundamental_insights"  : [],       # Empty list — operator.add will append
        "next_agent"            : "",
        "analysis_complete"     : False,
        "final_report"          : "",
        "recommendation"        : "",

        # Audit trail fields
        "agent_steps"           : [],       # Will accumulate one entry per agent
        "errors"                : [],       # Will accumulate any errors

        # Required by MessagesState base class
        "messages"              : [],       # Agent conversation history
    }

    # ── Execute the Graph ──────────────────────────────────────────────────
    # .invoke() runs the graph SYNCHRONOUSLY to completion.
    # It executes: supervisor → market_data → supervisor → risk → supervisor
    #              → fundamental → supervisor → report_writer → supervisor → END
    # Returns the FINAL state after all nodes have run.
    logger.info("[PIPELINE] Invoking graph...")
    final_state = graph.invoke(initial_state)

    logger.info(
        f"[PIPELINE] Analysis complete! "
        f"Recommendation: {final_state.get('recommendation', 'N/A')}"
    )
    logger.info(
        f"[PIPELINE] Agent steps taken: {len(final_state.get('agent_steps', []))}"
    )

    return final_state


# =============================================================================
# STREAMING PIPELINE — For real-time output to UI
# =============================================================================

def stream_financial_analysis(ticker: str, analysis_request: str = ""):
    """
    Generator that streams pipeline results node-by-node.

    WHY STREAMING?
        The full pipeline takes 30-60 seconds (4+ LLM calls + API calls).
        Streaming lets the UI show progress in real-time instead of waiting.

        Each yield delivers the output of ONE agent as it completes.
        The UI can display: "Market Data collected... Risk analysis done..."

    Usage:
        for chunk in stream_financial_analysis("AAPL"):
            print(chunk)  # Each chunk is one agent's state update

    Args:
        ticker:           Stock symbol
        analysis_request: Custom analysis instruction

    Yields:
        dict: Each agent's partial state update as it completes
    """
    logger.info(f"[PIPELINE STREAM] Starting streamed analysis for {ticker}")

    graph = build_financial_analysis_graph()

    initial_state = {
        "ticker"           : ticker.upper(),
        "analysis_request" : analysis_request or "Provide a comprehensive investment analysis",
        "company_name"     : "",
        "market_data"      : {},
        "risk_metrics"     : {},
        "risk_insights"    : [],
        "fundamental_data" : {},
        "fundamental_insights": [],
        "next_agent"       : "",
        "analysis_complete": False,
        "final_report"     : "",
        "recommendation"   : "",
        "agent_steps"      : [],
        "errors"           : [],
        "messages"         : [],
    }

    # .stream() returns a generator of (node_name, state_update) tuples
    # Each tuple is yielded as one node completes its work
    for state_chunk in graph.stream(initial_state):
        # state_chunk is a dict: {node_name: {partial_state_update}}
        # We yield it so the caller can process each agent's output
        yield state_chunk


# =============================================================================
# MODULE-LEVEL GRAPH INSTANCE (Optional Singleton Pattern)
# =============================================================================
# For production use: build the graph once at module import time
# and reuse it across multiple requests (much more efficient)
# Uncomment this in production:

# _graph_instance = build_financial_analysis_graph()
#
# def get_graph():
#     """Return the singleton graph instance."""
#     return _graph_instance