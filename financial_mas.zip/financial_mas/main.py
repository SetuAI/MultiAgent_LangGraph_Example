"""
=============================================================================
main.py — Command-Line Entry Point for the Financial MAS Pipeline
=============================================================================

WHAT THIS FILE DOES:
    Provides a clean command-line interface (CLI) to run the full
    multi-agent analysis pipeline without needing the FastAPI server
    or Streamlit UI.

    Useful for:
        - Quick testing during development
        - Batch analysis (run for multiple tickers)
        - Cron jobs and automated reporting
        - Teaching: see the full pipeline output in the terminal

USAGE:
    # Basic usage
    python main.py

    # With a specific ticker
    python main.py --ticker MSFT

    # With custom analysis request
    python main.py --ticker TSLA --request "Focus on EV market growth and competition"

    # Multiple tickers (batch mode)
    python main.py --ticker AAPL --ticker MSFT --ticker NVDA

    # Save report to file
    python main.py --ticker AAPL --output report.md

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import os
import sys
import json
import logging
import argparse                         # For parsing command-line arguments
from datetime import datetime
from pathlib import Path                # For file system operations

# ── Configure logging FIRST ────────────────────────────────────────────────
# Set up logging before any other imports that might use loggers
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


# =============================================================================
# CLI ARGUMENT PARSER
# =============================================================================

def create_arg_parser() -> argparse.ArgumentParser:
    """
    Define and return the CLI argument parser.

    argparse is the standard library for building CLIs in Python.
    It automatically generates --help text from the descriptions below.
    """
    parser = argparse.ArgumentParser(
        prog="financial-mas",
        description=(
            "Financial Multi-Agent Analysis System\n"
            "Powered by LangGraph + OpenAI\n\n"
            "Example:\n"
            "  python main.py --ticker AAPL\n"
            "  python main.py --ticker TSLA --request 'Focus on growth potential'"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter
    )

    parser.add_argument(
        "--ticker",
        type=str,
        default="AAPL",
        help="Stock ticker symbol to analyze (default: AAPL)"
    )

    parser.add_argument(
        "--request",
        type=str,
        default="Provide a comprehensive investment analysis with buy/hold/sell recommendation",
        help="Custom analysis focus or question"
    )

    parser.add_argument(
        "--output",
        type=str,
        default=None,
        help="Optional: save the report to this file path (e.g., report.md)"
    )

    parser.add_argument(
        "--json",
        action="store_true",           # Flag: --json means True, absence means False
        help="Output full state as JSON (useful for debugging)"
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose logging (shows all agent LLM calls)"
    )

    return parser


# =============================================================================
# DISPLAY HELPERS
# =============================================================================

def print_banner():
    """Print the application banner to the terminal."""
    banner = """
╔══════════════════════════════════════════════════════════════════╗
║         FINANCIAL MULTI-AGENT SYSTEM (MAS)                      ║
║         LangGraph × OpenAI × yfinance                           ║
║                                                                  ║
║  Agents: Supervisor → Market Data → Risk → Fundamental → Writer ║
╚══════════════════════════════════════════════════════════════════╝
    """
    print(banner)


def print_section(title: str, content: str, width: int = 70):
    """Print a formatted section with borders."""
    print(f"\n{'─' * width}")
    print(f"  {title}")
    print(f"{'─' * width}")
    print(content)


def print_agent_steps(steps: list[str]):
    """Print the agent execution timeline in a readable format."""
    print_section("📋 AGENT EXECUTION TIMELINE", "")

    # Map agent prefixes to emoji icons
    icon_map = {
        "SUPERVISOR"         : "🔵",
        "MARKET_DATA_AGENT"  : "📊",
        "RISK_ANALYST"       : "⚠️ ",
        "FUNDAMENTAL_ANALYST": "📈",
        "REPORT_WRITER"      : "📝",
    }

    for i, step in enumerate(steps, 1):
        # Find matching icon
        icon = "  "
        for key, emoji in icon_map.items():
            if key in step:
                icon = emoji
                break
        print(f"  {i:2d}. {icon} {step}")


def print_key_metrics(state: dict):
    """Print a summary table of key financial metrics."""
    print_section("📊 KEY METRICS SUMMARY", "")

    market_data  = state.get("market_data", {})
    risk_metrics = state.get("risk_metrics", {})
    fund_data    = state.get("fundamental_data", {})

    # ── Market Data ────────────────────────────────────────────────────────
    print("  MARKET DATA:")
    price     = market_data.get("current_price", "N/A")
    chg_pct   = market_data.get("price_change_pct", 0)
    mkt_cap   = market_data.get("market_cap", 0)
    print(f"    Current Price : ${price}")
    print(f"    Daily Change  : {chg_pct:+.2f}%" if isinstance(chg_pct, (int, float)) else f"    Daily Change  : N/A")
    print(f"    Market Cap    : ${mkt_cap/1e9:.2f}B" if mkt_cap else f"    Market Cap    : N/A")
    print(f"    52W Range     : ${market_data.get('week_52_low', 'N/A')} - ${market_data.get('week_52_high', 'N/A')}")

    print()

    # ── Risk Metrics ───────────────────────────────────────────────────────
    print("  RISK METRICS:")
    print(f"    Risk Level    : {risk_metrics.get('risk_level', 'N/A')}")
    print(f"    Volatility    : {risk_metrics.get('annualized_volatility_pct', 'N/A')}% (annualized)")
    print(f"    Beta          : {risk_metrics.get('beta', 'N/A')}")
    print(f"    Sharpe Ratio  : {risk_metrics.get('sharpe_ratio', 'N/A')}")
    print(f"    VaR (95% day) : {risk_metrics.get('var_95_daily_pct', 'N/A')}%")
    print(f"    Max Drawdown  : {risk_metrics.get('max_drawdown_pct', 'N/A')}%")

    print()

    # ── Fundamental Metrics ────────────────────────────────────────────────
    print("  FUNDAMENTAL METRICS:")
    print(f"    P/E Ratio     : {fund_data.get('pe_ratio', 'N/A')}x")
    print(f"    Forward P/E   : {fund_data.get('forward_pe', 'N/A')}x")
    print(f"    EPS (TTM)     : ${fund_data.get('eps_ttm', 'N/A')}")
    print(f"    Revenue Growth: {fund_data.get('revenue_growth_pct', 'N/A')}%")
    print(f"    Net Margin    : {fund_data.get('net_margin_pct', 'N/A')}%")
    print(f"    Debt/Equity   : {fund_data.get('debt_to_equity', 'N/A')}x")
    print(f"    ROE           : {fund_data.get('roe_pct', 'N/A')}%")
    print(f"    Free Cash Flow: ${fund_data.get('free_cash_flow_usd', 0)/1e9:.2f}B" if fund_data.get("free_cash_flow_usd") else "    Free Cash Flow: N/A")


# =============================================================================
# MAIN EXECUTION FUNCTION
# =============================================================================

def main():
    """
    Main entry point: parse args, run the pipeline, display results.

    Execution flow:
        1. Parse CLI arguments
        2. Validate environment (API key present?)
        3. Print banner and configuration
        4. Run the LangGraph pipeline
        5. Display results (metrics, insights, report)
        6. Optionally save to file
    """
    # ── Parse CLI arguments ────────────────────────────────────────────────
    parser = create_arg_parser()
    args   = parser.parse_args()

    # ── Verbose logging ────────────────────────────────────────────────────
    if args.verbose:
        # Set all loggers to DEBUG level for maximum visibility
        logging.getLogger().setLevel(logging.DEBUG)
        logging.getLogger("httpx").setLevel(logging.WARNING)       # Suppress HTTP noise
        logging.getLogger("urllib3").setLevel(logging.WARNING)     # Suppress urllib3 noise

    print_banner()

    # ── Validate API Key ───────────────────────────────────────────────────
    api_key = os.getenv("OPENAI_API_KEY", "")
    if not api_key:
        print("❌ ERROR: OPENAI_API_KEY environment variable is not set!")
        print("\nTo fix this, run one of:")
        print("  export OPENAI_API_KEY='sk-...'           (Linux/Mac)")
        print("  set OPENAI_API_KEY=sk-...               (Windows CMD)")
        print("  $env:OPENAI_API_KEY='sk-...'            (Windows PowerShell)")
        sys.exit(1)

    ticker  = args.ticker.upper().strip()
    request = args.request

    print(f"  Ticker    : {ticker}")
    print(f"  Request   : {request[:80]}{'...' if len(request) > 80 else ''}")
    print(f"  Timestamp : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"\n  Starting pipeline...")

    # ── Import and run the pipeline ────────────────────────────────────────
    # Import here (not at top level) to avoid slow imports on --help
    from graph.pipeline import run_financial_analysis

    start_time = datetime.now()

    try:
        # Run the full multi-agent pipeline
        # This is synchronous — it blocks until all 4 agents complete
        print(f"\n  🔵 Supervisor Agent    : initializing...")
        print(f"  📊 Market Data Agent   : fetching prices & company info...")

        final_state = run_financial_analysis(
            ticker=ticker,
            analysis_request=request,
        )

        elapsed = (datetime.now() - start_time).total_seconds()

        print(f"\n  ✅ Pipeline complete in {elapsed:.1f} seconds!")

    except KeyboardInterrupt:
        print("\n\n⚠️  Analysis interrupted by user.")
        sys.exit(0)

    except Exception as e:
        print(f"\n❌ Pipeline failed: {e}")
        logger.exception("Full traceback:")
        sys.exit(1)

    # ── Display Results ────────────────────────────────────────────────────

    # Agent execution timeline
    print_agent_steps(final_state.get("agent_steps", []))

    # Key metrics summary table
    print_key_metrics(final_state)

    # Risk insights from Risk Analyst Agent
    risk_insights = final_state.get("risk_insights", [])
    if risk_insights:
        print_section("⚠️  RISK ANALYST INSIGHTS", "")
        for insight in risk_insights:
            if insight.strip():
                print(f"  • {insight}")

    # Fundamental insights from Fundamental Analyst Agent
    fund_insights = final_state.get("fundamental_insights", [])
    if fund_insights:
        print_section("📈 FUNDAMENTAL ANALYST INSIGHTS", "")
        for insight in fund_insights:
            if insight.strip():
                print(f"  • {insight}")

    # Final recommendation
    recommendation = final_state.get("recommendation", "HOLD")
    rec_symbols = {"BUY": "🟢", "HOLD": "🟡", "SELL": "🔴"}
    rec_action  = recommendation.split("|")[0].strip()
    rec_emoji   = rec_symbols.get(rec_action, "⚪")

    print_section(f"{rec_emoji} RECOMMENDATION: {recommendation}", "")

    # Full investment report
    final_report = final_state.get("final_report", "")
    if final_report:
        print_section("📝 FULL INVESTMENT BRIEF", "")
        print(final_report)

    # ── JSON Output Mode ───────────────────────────────────────────────────
    if args.json:
        # Print the full state as formatted JSON
        # Exclude binary/large fields that don't serialize well
        serializable_state = {
            k: v for k, v in final_state.items()
            if k != "messages"  # BaseMessage objects aren't JSON-serializable
        }
        print_section("🔧 FULL STATE (JSON)", "")
        print(json.dumps(serializable_state, indent=2, default=str))

    # ── Save Report to File ────────────────────────────────────────────────
    if args.output:
        output_path = Path(args.output)

        # Write the Markdown report to file
        report_content = (
            f"# Investment Analysis: {final_state.get('company_name', ticker)} ({ticker})\n\n"
            f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"**Recommendation:** {recommendation}\n\n"
            f"---\n\n"
            f"{final_report}\n\n"
            f"---\n\n"
            f"## Agent Execution Steps\n\n"
            + "\n".join(f"- {step}" for step in final_state.get("agent_steps", []))
        )

        output_path.write_text(report_content, encoding="utf-8")
        print(f"\n  💾 Report saved to: {output_path.absolute()}")

    print(f"\n{'═' * 70}")
    print(f"  Analysis complete. Total time: {elapsed:.1f}s")
    print(f"{'═' * 70}\n")


# =============================================================================
# SCRIPT ENTRY POINT
# =============================================================================

if __name__ == "__main__":
    # This block only runs when you execute: python main.py
    # It does NOT run when this module is imported by other modules
    main()