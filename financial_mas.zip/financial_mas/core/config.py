"""
=============================================================================
core/config.py — System-wide Configuration & Shared State Schema
=============================================================================

WHY THIS FILE EXISTS:
    In any production multi-agent system, you need a single source of truth
    for two things:
        1. Configuration  — model names, temperatures, API keys
        2. State schema   — the shared "memory" that all agents read and write

    Think of the STATE as a baton in a relay race. Each agent:
        - Picks up the baton (reads the current state)
        - Does their work (analyzes data, generates insights)
        - Passes the baton forward (updates the state with their findings)

LANGGRAPH STATE CONCEPT:
    LangGraph uses a concept called "TypedDict" as the state container.
    Every agent in the graph receives the FULL state and returns a PARTIAL
    update. LangGraph merges the updates automatically using "reducers"
    (we'll see Annotated[list, operator.add] — this tells LangGraph to
    APPEND to lists rather than overwrite them).

=============================================================================
"""

# ── Standard library ──────────────────────────────────────────────────────
import operator                     # For the `add` reducer used in state lists
from typing import Annotated        # For attaching metadata (reducers) to types
from typing import Any              # Generic type for flexible dict values

# ── Third-party: LangGraph ─────────────────────────────────────────────────
from langgraph.graph import MessagesState  # Base state class from LangGraph

# ── Third-party: Pydantic Settings ────────────────────────────────────────
from pydantic_settings import BaseSettings  # Auto-loads from .env files
from pydantic import Field                  # For field validation and defaults


# =============================================================================
# SECTION 1: Application Settings
# =============================================================================
# Pydantic BaseSettings reads values from environment variables automatically.
# Priority order: environment variable > .env file > default value
# This is the CORRECT production pattern — never hardcode API keys!

class Settings(BaseSettings):
    """
    Central configuration object for the entire application.

    Usage:
        from core.config import settings
        client = OpenAI(api_key=settings.openai_api_key)
    """

    # ── OpenAI ────────────────────────────────────────────────────────────
    openai_api_key: str = Field(
        default="",
        description="Your OpenAI API key — set via OPENAI_API_KEY env var"
    )

    # ── LLM Model Selection ────────────────────────────────────────────────
    # gpt-4o gives the best reasoning for financial analysis
    # gpt-4o-mini is cheaper but less accurate for complex tasks
    llm_model: str = Field(
        default="gpt-4o-mini",           # Use mini for cost efficiency in demos
        description="OpenAI model to use for all agents"
    )

    # ── Temperature Controls ───────────────────────────────────────────────
    # Temperature controls LLM creativity/randomness:
    #   0.0 = deterministic, analytical (good for data analysis)
    #   0.7 = balanced (good for report writing)
    #   1.0 = creative (good for brainstorming)
    supervisor_temperature: float = Field(
        default=0.0,
        description="Supervisor needs to be deterministic — it routes tasks"
    )
    analyst_temperature: float = Field(
        default=0.1,
        description="Analysts need to be mostly deterministic for consistency"
    )
    writer_temperature: float = Field(
        default=0.4,
        description="Report writer can be slightly creative for readability"
    )

    # ── Application Settings ───────────────────────────────────────────────
    app_name: str = "Financial Multi-Agent System"
    app_version: str = "1.0.0"
    debug: bool = Field(default=False, description="Enable verbose logging")

    class Config:
        # Tell Pydantic to look for a .env file in the project root
        env_file = ".env"
        # Allow extra fields in the .env file without raising errors
        extra = "ignore"


# Create a single, shared settings instance imported by all modules
# This is the Singleton pattern — one instance shared across the entire app
settings = Settings()


# =============================================================================
# SECTION 2: Shared Agent State (The "Baton")
# =============================================================================
# This is the most important design decision in a LangGraph multi-agent system.
# Every agent reads from AND writes to this shared state dictionary.
#
# KEY CONCEPT — Annotated[list, operator.add]:
#   When Agent A writes {"risk_insights": ["High volatility"]}
#   and Agent B writes {"risk_insights": ["Low liquidity"]}
#   LangGraph uses operator.add to MERGE them into:
#   {"risk_insights": ["High volatility", "Low liquidity"]}
#   WITHOUT operator.add, Agent B would OVERWRITE Agent A's work!

class FinancialAnalysisState(MessagesState):
    """
    The shared state (baton) passed between all agents in the graph.

    INHERITANCE:
        MessagesState gives us `messages: list[BaseMessage]` out of the box.
        This is the conversation history between agents and tools.

    EACH AGENT'S RESPONSIBILITY:
        - market_data_agent   → fills: ticker, market_data
        - risk_analyst_agent  → fills: risk_metrics, risk_insights
        - fundamental_analyst → fills: fundamental_data, fundamental_insights
        - report_writer_agent → fills: final_report
        - supervisor          → fills: next_agent, analysis_complete
    """

    # ── Input ──────────────────────────────────────────────────────────────
    ticker: str                     # Stock ticker symbol, e.g., "AAPL"
    company_name: str               # Human-readable name, e.g., "Apple Inc."
    analysis_request: str           # Free-text request from the user

    # ── Market Data Agent Output ───────────────────────────────────────────
    # Dict contains: current_price, open, high, low, volume, 52w_high, etc.
    market_data: dict[str, Any]     # Raw OHLCV and price data from yfinance
    # {"price" : 3.453}

    # ── Risk Analyst Agent Output ──────────────────────────────────────────
    risk_metrics: dict[str, Any]    # Calculated: volatility, beta, VaR, Sharpe
    risk_insights: Annotated[       # Text summaries — APPENDED across agents
        list[str],
        operator.add                # LangGraph reducer: merge lists, don't overwrite
    ]

    # ── Fundamental Analyst Agent Output ──────────────────────────────────
    fundamental_data: dict[str, Any]  # P/E, EPS, revenue, margins, debt ratios
    fundamental_insights: Annotated[  # Text summaries — APPENDED across agents
        list[str],
        operator.add
    ]

    # ── Supervisor Control Fields ──────────────────────────────────────────
    # next_agent tells LangGraph's conditional router which node to visit next
    next_agent: str                 # e.g., "risk_analyst", "report_writer", "END"
    analysis_complete: bool         # Flag: True when report is ready

    # ── Report Writer Agent Output ─────────────────────────────────────────
    final_report: str               # The polished investment brief
    recommendation: str             # BUY / HOLD / SELL with confidence level

    # ── Audit Trail ────────────────────────────────────────────────────────
    # In production fintech, you MUST log every agent's action for compliance
    agent_steps: Annotated[         # Chronological log of agent actions
        list[str],
        operator.add
    ]
    errors: Annotated[              # Non-fatal errors — allows graceful degradation
        list[str],
        operator.add
    ]


# =============================================================================
# SECTION 3: Agent Names (Constants)
# =============================================================================
# Define agent name constants to avoid typo bugs across the codebase.
# If you rename an agent, you change it ONCE here — not in 10 files.

class AgentNames:
    """String constants for all agent node names in the LangGraph graph."""
    SUPERVISOR          = "supervisor"
    MARKET_DATA_AGENT   = "market_data_agent"
    RISK_ANALYST_AGENT  = "risk_analyst_agent"
    FUNDAMENTAL_ANALYST = "fundamental_analyst_agent"
    REPORT_WRITER       = "report_writer_agent"
    END                 = "END"         # Special LangGraph terminal node name